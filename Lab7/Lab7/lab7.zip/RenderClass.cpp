﻿#include "framework.h"
#include "RenderClass.h"
#include "DDSTextureLoader11.h"

#include <filesystem>

#include <dxgi.h>
#include <d3d11.h>
#include <d3dcompiler.h>

#pragma comment (lib, "d3dcompiler.lib")
#pragma comment (lib, "d3d11.lib")
#pragma comment (lib, "dxgi.lib")

#define STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_WRITE_IMPLEMENTATION

//#include "src/tiny_gltf.h"
#include "src/stb_image.h"

#pragma comment(lib, "comctl32.lib")


struct CubeVertex
{
    XMFLOAT3 xyz;
    XMFLOAT3 normal;
    XMFLOAT2 uv;
};

struct MatrixBuffer
{
    XMMATRIX m;
};

struct CameraBuffer
{
    XMMATRIX vp;
    XMFLOAT3 cameraPos;
};

struct ColorBuffer
{
    XMFLOAT4 color;
};

struct PointLight
{
    XMFLOAT3 Position;
    float Range;
    XMFLOAT3 Color;
    float Intensity;
};

struct FullScreenVertex
{
    XMFLOAT3 Pos;
    XMFLOAT2 TexCoord;
};

struct ToneMapParamsCB
{
    XMFLOAT4 Params;
};

struct MaterialParamsCB
{
    XMFLOAT4 Surface;
    XMFLOAT4 Albedo;
    XMFLOAT4 DebugView; 
    XMFLOAT4 Emissive; 
};

struct BloomParamsCB
{
    XMFLOAT4 Params0; 
    XMFLOAT4 Params1; 
};

struct SpecularPrefilterCB
{
    XMFLOAT4 Params;
};

static XMMATRIX BuildViewProjMatrix(
    const XMFLOAT3& cameraPos,
    float lrAngle,
    float udAngle,
    float aspect)
{
    XMVECTOR direction = XMVectorSet(
        cosf(udAngle) * sinf(lrAngle),
        sinf(udAngle),
        cosf(udAngle) * cosf(lrAngle),
        0.0f
    );

    XMVECTOR eyePos = XMVectorSet(cameraPos.x, cameraPos.y, cameraPos.z, 1.0f);
    XMVECTOR focusPoint = XMVectorAdd(eyePos, direction);
    XMVECTOR upDir = XMVectorSet(0.0f, 1.0f, 0.0f, 0.0f);
    XMMATRIX view = XMMatrixLookAtLH(eyePos, focusPoint, upDir);
    XMMATRIX proj = XMMatrixPerspectiveFovLH(XM_PIDIV4, aspect, 0.1f, 100.0f);

    return view * proj;
}

static std::wstring ToLowerCopy(std::wstring s)
{
    std::transform(s.begin(), s.end(), s.begin(), ::towlower);
    return s;
};

bool RenderClass::HasExtension(const std::wstring& path, const std::wstring& ext) const
{
    std::filesystem::path p(path);
    return ToLowerCopy(p.extension().wstring()) == ToLowerCopy(ext);
};

std::vector<RenderClass::SceneModelDesc> RenderClass::GetSceneModelDescs() const
{
    return
    {
        {
            L"models/penguin/penguin.gltf",
            XMFLOAT3(-2.5f, 0.0f, 0.0f),
            XMFLOAT3(90.0f, 180.0f, 0.0f),
            XMFLOAT3(0.1f, 0.1f, 0.1f),
            true,
            true
        },
        {
            L"models/cakepop/Cake_ Pop.gltf",
            XMFLOAT3(10.0f, 0.0f, 1.5f),
            XMFLOAT3(0.0f, 180.0f, 0.0f),
            XMFLOAT3(1.0f, 1.0f, 1.0f),
            true,
            true
        },
        {
            L"models/bunny/bunny_blend.gltf",
            XMFLOAT3(10.0f, 0.0f, 1.5f),
            XMFLOAT3(0.0f, -90.0f, 0.0f),
            XMFLOAT3(1.0f, 1.0f, 1.0f),
            true,
            true
        }
        //{
        //    L"models/columns/colonne.gltf",
        //    XMFLOAT3(-10.0f, 0.0f, 30.5f),
        //    XMFLOAT3(0.0f, -45.0f, 0.0f),
        //    XMFLOAT3(0.02f, 0.02f, 0.02f),
        //    true,
        //    true
        //}
    };
}

HRESULT RenderClass::Init(HWND hWnd, WCHAR szTitle[], WCHAR szWindowClass[])
{
    m_szTitle = szTitle;
    m_szWindowClass = szWindowClass;

    HRESULT result;

    IDXGIFactory* pFactory = nullptr;
    result = CreateDXGIFactory(__uuidof(IDXGIFactory), (void**)&pFactory);

    IDXGIAdapter* pSelectedAdapter = NULL;
    if (SUCCEEDED(result))
    {
        IDXGIAdapter* pAdapter = NULL;
        UINT adapterIdx = 0;
        while (SUCCEEDED(pFactory->EnumAdapters(adapterIdx, &pAdapter)))
        {
            DXGI_ADAPTER_DESC desc;
            pAdapter->GetDesc(&desc);

            if (wcscmp(desc.Description, L"Microsoft Basic Render Driver") != 0)
            {
                pSelectedAdapter = pAdapter;
                break;
            }

            pAdapter->Release();

            adapterIdx++;
        }
    }

    D3D_FEATURE_LEVEL level;
    D3D_FEATURE_LEVEL levels[] = { D3D_FEATURE_LEVEL_11_0 };
    if (SUCCEEDED(result))
    {
        UINT flags = 0;
#ifdef _DEBUG
        flags |= D3D11_CREATE_DEVICE_DEBUG;
#endif
        result = D3D11CreateDevice(pSelectedAdapter, D3D_DRIVER_TYPE_UNKNOWN, NULL,
            flags, levels, 1, D3D11_SDK_VERSION, &m_pDevice, &level, &m_pDeviceContext);
    }

    if (SUCCEEDED(result) && m_pDeviceContext)
        m_pDeviceContext->QueryInterface(__uuidof(ID3DUserDefinedAnnotation), (void**)&m_pAnnotation);

    if (SUCCEEDED(result))
    {
        DXGI_SWAP_CHAIN_DESC swapChainDesc = { 0 };
        swapChainDesc.BufferCount = 2;
        swapChainDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
        swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        swapChainDesc.OutputWindow = hWnd;
        swapChainDesc.SampleDesc.Count = 1;
        swapChainDesc.SampleDesc.Quality = 0;
        swapChainDesc.Windowed = true;
        swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
        swapChainDesc.Flags = 0;

        result = pFactory->CreateSwapChain(m_pDevice, &swapChainDesc, &m_pSwapChain);
    }

    if (SUCCEEDED(result))
    {
        RECT rc;
        GetClientRect(hWnd, &rc);
        UINT width = rc.right - rc.left;
        UINT height = rc.bottom - rc.top;
        result = ConfigureBackBuffer(width, height);

        if (SUCCEEDED(result))
            result = CreateHDRSceneTexture(width, height);

        if (SUCCEEDED(result))
            result = CreateBloomResources(width, height);

        if (SUCCEEDED(result))
            result = InitLuminanceResources(width, height);

        D3D11_VIEWPORT vp = {};
        vp.Width = (FLOAT)width;
        vp.Height = (FLOAT)height;
        vp.MinDepth = 0.0f;
        vp.MaxDepth = 1.0f;
        vp.TopLeftX = 0;
        vp.TopLeftY = 0;
        m_pDeviceContext->RSSetViewports(1, &vp);
    }

    if (SUCCEEDED(result))
        result = InitBufferShader();

    if (SUCCEEDED(result))
    {
        result = CreateShadowResources(2048);
        if (FAILED(result))
            return result;
    }

    const std::vector<SceneModelDesc> sceneModels = GetSceneModelDescs();

    for (const auto& desc : sceneModels)
    {
        int resourceIndex = -1;
        if (!LoadModelResource(desc.FilePath, resourceIndex))
        {
            std::wstring msg = L"Failed to load model: " + desc.FilePath + L"\n";
            OutputDebugStringW(msg.c_str());
        }
    }

    if (SUCCEEDED(result))
    {
        result = CreateGroundPlane(40.0f, 1.0f);
        if (FAILED(result))
            return result;

        LoadSceneModels();
    }

    if (SUCCEEDED(result))
    {
        m_CameraR = 5.0f;
        m_CameraPosition = XMFLOAT3(0.0f, 0.0f, -m_CameraR);
        m_CubeAngle = 0.0f;
        m_LRAngle = 0.0f;
        m_UDAngle = 0.0f;
        m_CubePosition = XMFLOAT3(0.0f, 0.0f, 0.0f);
    }

    if (pSelectedAdapter)
        pSelectedAdapter->Release();

    if (pFactory)
        pFactory->Release();

    if (FAILED(result))
        Terminate();

    InitImGui(hWnd);

    return result;
}

HRESULT RenderClass::InitBufferShader()
{
    D3D11_INPUT_ELEMENT_DESC layout[] =
    {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(GltfVertex, Position), D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "NORMAL", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, offsetof(GltfVertex, Normal), D3D11_INPUT_PER_VERTEX_DATA, 0 },
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, offsetof(GltfVertex, TexCoord), D3D11_INPUT_PER_VERTEX_DATA, 0 }
    };

    HRESULT result = S_OK;

    ID3DBlob* pVertexCode = nullptr;
    if (SUCCEEDED(result))
        result = CompileShader(L"ColorVertex.vs", &m_pVertexShader, nullptr, &pVertexCode);
    
    if (SUCCEEDED(result))
        result = CompileShader(L"ColorPixel.ps", nullptr, &m_pPixelShader);
    
    if (SUCCEEDED(result))
        result = CompileShader(L"ShadowVertex.vs", &m_pShadowVertexShader, nullptr);

    if (FAILED(result))
        return result;

    D3D11_SAMPLER_DESC shadowSamplerDesc = {};
    shadowSamplerDesc.Filter = D3D11_FILTER_COMPARISON_MIN_MAG_LINEAR_MIP_POINT;
    shadowSamplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_BORDER;
    shadowSamplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_BORDER;
    shadowSamplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_BORDER;
    shadowSamplerDesc.ComparisonFunc = D3D11_COMPARISON_LESS_EQUAL;
    shadowSamplerDesc.BorderColor[0] = 1.0f;
    shadowSamplerDesc.BorderColor[1] = 1.0f;
    shadowSamplerDesc.BorderColor[2] = 1.0f;
    shadowSamplerDesc.BorderColor[3] = 1.0f;
    result = m_pDevice->CreateSamplerState(&shadowSamplerDesc, &m_pShadowSampler);
    if (FAILED(result))
        return result;

    D3D11_RASTERIZER_DESC shadowRsDesc = {};
    shadowRsDesc.FillMode = D3D11_FILL_SOLID;
    shadowRsDesc.CullMode = D3D11_CULL_BACK;
    shadowRsDesc.DepthClipEnable = TRUE;
    shadowRsDesc.SlopeScaledDepthBias = (INT)m_ShadowSlopeBias;
    shadowRsDesc.DepthBias = (INT)(m_ShadowBias * 100000.0f);
    shadowRsDesc.DepthBiasClamp = 0.0f;
    result = m_pDevice->CreateRasterizerState(&shadowRsDesc, &m_pShadowRasterState);
    if (FAILED(result))
        return result;

    if (SUCCEEDED(result))
        result = m_pDevice->CreateInputLayout(layout, 3, pVertexCode->GetBufferPointer(), pVertexCode->GetBufferSize(), &m_pLayout);

    if (pVertexCode)
        pVertexCode->Release();

    if (SUCCEEDED(result))
        result = CompileShader(L"LightPixel.ps", nullptr, &m_pLightPixelShader);

    result = CompileShader(L"ToneMapPixel.ps", nullptr, &m_pToneMapPS);

    if (SUCCEEDED(result))
        result = CompileShader(L"BloomExtract.ps", nullptr, &m_pBloomExtractPS);

    if (SUCCEEDED(result))
        result = CompileShader(L"BloomBlur.ps", nullptr, &m_pBloomBlurPS);

    if (FAILED(result))
        return result;


    ID3DBlob* pSkyVSCode = nullptr;
    if (SUCCEEDED(result))
        result = CompileShader(L"SkyVertex.vs", &m_pSkyVertexShader, nullptr, &pSkyVSCode);

    if (SUCCEEDED(result))
    {
        D3D11_INPUT_ELEMENT_DESC skyLayout[] =
        {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 }
        };
        result = m_pDevice->CreateInputLayout(
            skyLayout,
            1,
            pSkyVSCode->GetBufferPointer(),
            pSkyVSCode->GetBufferSize(),
            &m_pSkyLayout
        );
    }
    if (pSkyVSCode)
        pSkyVSCode->Release();

    if (SUCCEEDED(result))
        result = CompileShader(L"SkyPixel.ps", nullptr, &m_pSkyPixelShader);

    if (FAILED(result))
        return result;

    D3D11_BUFFER_DESC cbDesc = {};
    cbDesc.Usage = D3D11_USAGE_DYNAMIC;
    cbDesc.ByteWidth = sizeof(ToneMapParamsCB);
    cbDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    cbDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    result = m_pDevice->CreateBuffer(&cbDesc, nullptr, &m_pToneMapCB);
    if (FAILED(result))
        return result;

    D3D11_BUFFER_DESC bloomCBDesc = {};
    bloomCBDesc.Usage = D3D11_USAGE_DYNAMIC;
    bloomCBDesc.ByteWidth = sizeof(BloomParamsCB);
    bloomCBDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    bloomCBDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    result = m_pDevice->CreateBuffer(&bloomCBDesc, nullptr, &m_pBloomCB);
    if (FAILED(result))
        return result;

    const int stacks = 32;
    const int slices = 64;
    const float radius = 1.0f;
    std::vector<CubeVertex> vertices;
    std::vector<WORD> indices;
    vertices.reserve((stacks + 1) * (slices + 1));
    indices.reserve(stacks * slices * 6);
    const float PI = 3.14159265358979323846f;
    for (int i = 0; i <= stacks; ++i)
    {
        float v = (float)i / stacks;
        float phi = v * PI; 
        for (int j = 0; j <= slices; ++j)
        {
            float u = (float)j / slices;
            float theta = u * 2.0f * PI;
            float x = std::sin(phi) * std::cos(theta);
            float y = std::cos(phi);
            float z = std::sin(phi) * std::sin(theta);
            CubeVertex vert;
            vert.xyz = XMFLOAT3(radius * x, radius * y, radius * z);
            vert.normal = XMFLOAT3(x, y, z); 
            vert.uv = XMFLOAT2(u, 1.0f - v);
            vertices.push_back(vert);
        }
    }
    for (int i = 0; i < stacks; ++i)
    {
        for (int j = 0; j < slices; ++j)
        {
            WORD a = (WORD)(i * (slices + 1) + j);
            WORD b = (WORD)(a + (slices + 1));
            WORD c = (WORD)(a + 1);
            WORD d = (WORD)(b + 1);
            indices.push_back(a);
            indices.push_back(c);
            indices.push_back(b);
            
            indices.push_back(c);
            indices.push_back(d);
            indices.push_back(b);
        }
    }

    m_indexCount = (UINT)indices.size();

    D3D11_BUFFER_DESC lightBufferDesc = {};
    lightBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
    lightBufferDesc.ByteWidth = sizeof(PointLight) * 3;
    lightBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    lightBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    result = m_pDevice->CreateBuffer(&lightBufferDesc, nullptr, &m_pLightBuffer);
    if (FAILED(result))
        return result;

    D3D11_BUFFER_DESC bd = {};
    bd.Usage = D3D11_USAGE_DEFAULT;
    bd.ByteWidth = (UINT)(sizeof(CubeVertex) * vertices.size());
    bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;
    bd.CPUAccessFlags = 0;

    D3D11_SUBRESOURCE_DATA initData = {};
    initData.pSysMem = vertices.data();
    result = m_pDevice->CreateBuffer(&bd, &initData, &m_pVertexBuffer);
    if (FAILED(result))
        return result;

    bd.Usage = D3D11_USAGE_DEFAULT;
    bd.ByteWidth = (UINT)(sizeof(WORD) * indices.size());
    bd.BindFlags = D3D11_BIND_INDEX_BUFFER;
    bd.CPUAccessFlags = 0;
    initData.pSysMem = indices.data();
    result = m_pDevice->CreateBuffer(&bd, &initData, &m_pIndexBuffer);
    if (FAILED(result))
        return result;

    bd.Usage = D3D11_USAGE_DEFAULT;
    bd.ByteWidth = sizeof(XMMATRIX);
    bd.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    bd.CPUAccessFlags = 0;
    result = m_pDevice->CreateBuffer(&bd, nullptr, &m_pModelBuffer);
    if (FAILED(result))
        return result;

    D3D11_BUFFER_DESC vpBufferDesc = {};
    vpBufferDesc.Usage = D3D11_USAGE_DYNAMIC;
    vpBufferDesc.ByteWidth = sizeof(CameraBuffer);
    vpBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    vpBufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    result = m_pDevice->CreateBuffer(&vpBufferDesc, nullptr, &m_pVPBuffer);
    if (FAILED(result))
        return result;

    D3D11_BUFFER_DESC colorBufferDesc = {};
    colorBufferDesc.Usage = D3D11_USAGE_DEFAULT;
    colorBufferDesc.ByteWidth = sizeof(ColorBuffer);
    colorBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    colorBufferDesc.CPUAccessFlags = 0;
    result = m_pDevice->CreateBuffer(&colorBufferDesc, nullptr, &m_pColorBuffer);
    if (FAILED(result))
        return result;

    D3D11_BUFFER_DESC materialBufferDesc = {};
    materialBufferDesc.Usage = D3D11_USAGE_DEFAULT;
    materialBufferDesc.ByteWidth = sizeof(MaterialParamsCB);
    materialBufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    materialBufferDesc.CPUAccessFlags = 0;
    result = m_pDevice->CreateBuffer(&materialBufferDesc, nullptr, &m_pMaterialBuffer);
    if (FAILED(result))
        return result;


    D3D11_BUFFER_DESC prefilterCBDesc = {};
    prefilterCBDesc.Usage = D3D11_USAGE_DEFAULT;
    prefilterCBDesc.ByteWidth = sizeof(SpecularPrefilterCB);
    prefilterCBDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    prefilterCBDesc.CPUAccessFlags = 0;
    result = m_pDevice->CreateBuffer(&prefilterCBDesc, nullptr, &m_pSpecularPrefilterCB);
    if (FAILED(result))
        return result;

    const wchar_t* albedoFiles[kSphereCount] =
    {
         L"textures/bark_brown_02_diff_4k.dds",
         L"textures/blue_metal_plate_diff_4k.dds",
         L"textures/fabric_leather_02_diff_4k.dds",
         L"textures/old_stone_wall_diff_4k.dds"
    };
    const wchar_t* normalFiles[kSphereCount] =
    {
         L"textures/KORA_DEREVA.dds",
         L"textures/sinushnaya_zhelezka.dds",
         L"textures/gladkaya_kozha.dds",
         L"textures/kameshki.dds"
    };
    for (int i = 0; i < kSphereCount; ++i)
    {
        result = DirectX::CreateDDSTextureFromFile(
            m_pDevice,
            albedoFiles[i],
            nullptr,
            &m_pTextureViews[i]
        );
        if (FAILED(result))
            return result;
        result = DirectX::CreateDDSTextureFromFile(
            m_pDevice,
            normalFiles[i],
            nullptr,
            &m_pNormalMapViews[i]
        );
        if (FAILED(result))
            return result;
    }


    //result = DirectX::CreateDDSTextureFromFileEx(
    //    m_pDevice,
    //    L"cubemaps/shanghai_box.dds",
    //    0,
    //    D3D11_USAGE_DEFAULT,
    //    D3D11_BIND_SHADER_RESOURCE,
    //    0,
    //    0,
    //    DirectX::DDS_LOADER_FORCE_SRGB, 
    //    nullptr,
    //    &m_pEnvironmentSRV
    //);

    result = CompileShader(L"HdrToCubemap.ps", nullptr, &m_pHdrToCubemapPS);
    if (FAILED(result))
        return result;

    result = CompileShader(L"IrradianceConvolution.ps", nullptr, &m_pIrradianceConvolutionPS);
    if (FAILED(result))
        return result;

    result = CompileShader(L"SpecularPrefilter.ps", nullptr, &m_pSpecularPrefilterPS);
    if (FAILED(result))
        return result;

    result = CompileShader(L"BRDFIntegration.ps", nullptr, &m_pBRDFIntegrationPS);
    if (FAILED(result))
        return result;

    D3D11_SAMPLER_DESC sampDesc = {};
    sampDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
    sampDesc.AddressU = D3D11_TEXTURE_ADDRESS_WRAP;
    sampDesc.AddressV = D3D11_TEXTURE_ADDRESS_WRAP;
    sampDesc.AddressW = D3D11_TEXTURE_ADDRESS_WRAP;
    sampDesc.ComparisonFunc = D3D11_COMPARISON_NEVER;
    sampDesc.MinLOD = 0;
    sampDesc.MaxLOD = D3D11_FLOAT32_MAX;
    result = m_pDevice->CreateSamplerState(&sampDesc, &m_pSamplerState);

    if (FAILED(result))
        return result;

    result = LoadEnvironmentMap(L"cubemaps/sunset_jhbcentral_4k.hdr");
    // result = LoadEnvironmentMap(L"cubemaps/shanghai_box.dds");
    if (FAILED(result))
    {
        MessageBox(nullptr, L"HDR environment load failed", L"Error", MB_OK);
        return result;
    }
    else
    {
        OutputDebugString(L"HDR environment loaded successfully\n");
    }

    if (!m_pBRDFLUTSRV)
    {
        result = GenerateBRDFLUT(512, 512, &m_pBRDFLUTSRV);
        if (FAILED(result))
        {
            MessageBox(nullptr, L"BRDF LUT generation failed", L"Error", MB_OK);
            return result;
        }
    }

    D3D11_RASTERIZER_DESC gltfRsDesc = {};
    gltfRsDesc.FillMode = D3D11_FILL_SOLID;
    gltfRsDesc.CullMode = D3D11_CULL_NONE;
    gltfRsDesc.FrontCounterClockwise = FALSE;
    gltfRsDesc.DepthClipEnable = TRUE;
    result = m_pDevice->CreateRasterizerState(&gltfRsDesc, &m_pGltfRasterState);
    if (FAILED(result))
        return result;

    ScanCubeMapsFolder();
    std::string currentFilename = "sunset_jhbcentral_4k.hdr";
    m_currentEnvIndex = -1;
    for (int i = 0; i < m_environmentFileNames.size(); ++i)
    {
        if (m_environmentFileNames[i] == currentFilename)
        {
            m_currentEnvIndex = i;
            m_prevEnvIndex = m_currentEnvIndex;
            break;
        }
    }

    D3D11_RASTERIZER_DESC rsDesc = {};
    rsDesc.FillMode = D3D11_FILL_SOLID;
    rsDesc.CullMode = D3D11_CULL_FRONT;
    rsDesc.FrontCounterClockwise = FALSE;
    rsDesc.DepthClipEnable = TRUE;
    result = m_pDevice->CreateRasterizerState(&rsDesc, &m_pSkyRasterState);
    if (FAILED(result))
        return result;

    D3D11_DEPTH_STENCIL_DESC dsDesc = {};
    dsDesc.DepthEnable = TRUE;
    dsDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ZERO;
    dsDesc.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;
    result = m_pDevice->CreateDepthStencilState(&dsDesc, &m_pSkyDepthState);
    if (FAILED(result))
        return result;

    return result;
}

HRESULT RenderClass::InitLuminanceResources(UINT width, UINT height)
{
    HRESULT result;

    for (int i = 0; i < 16; i++)
    {
        if (m_pLuminanceTextures[i])
        {
            m_pLuminanceTextures[i]->Release();
            m_pLuminanceTextures[i] = nullptr;
        }
        if (m_pLuminanceRTV[i])
        {
            m_pLuminanceRTV[i]->Release();
            m_pLuminanceRTV[i] = nullptr;
        }
        if (m_pLuminanceSRV[i])
        {
            m_pLuminanceSRV[i]->Release();
            m_pLuminanceSRV[i] = nullptr;
        }
        if (m_pLuminanceStagingTextures[i])
        {
            m_pLuminanceStagingTextures[i]->Release();
            m_pLuminanceStagingTextures[i] = nullptr;
        }
    }

    if (m_pLuminanceQuery)
    {
        m_pLuminanceQuery->Release();
        m_pLuminanceQuery = nullptr;
    }

    UINT minDim = std::min(width, height);
    m_LuminanceLevels = 0;

    UINT size = minDim;
    while (size >= 1)
    {
        m_LuminanceLevels++;
        size /= 2;
    }

    if (!m_pFullScreenVS)
    {
        result = CompileShader(L"FullScreenVS.vs", &m_pFullScreenVS, nullptr);
        if (FAILED(result))
            return result;
    }

    if (!m_pLuminancePS)
    {
        result = CompileShader(L"LuminancePixel.ps", nullptr, &m_pLuminancePS);
        if (FAILED(result))
            return result;
    }

    if (!m_pDownsamplePS)
    {
        result = CompileShader(L"LuminanceDownsample.ps", nullptr, &m_pDownsamplePS);
        if (FAILED(result))
            return result;
    }

    if (!m_pFullScreenLayout)
    {
        D3D11_INPUT_ELEMENT_DESC layout[] =
        {
            { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 },
            { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D11_INPUT_PER_VERTEX_DATA, 0 }
        };

        ID3DBlob* pVSBlob = nullptr;
        result = CompileShader(L"FullScreenVS.vs", nullptr, nullptr, &pVSBlob);
        if (FAILED(result))
            return result;

        result = m_pDevice->CreateInputLayout(layout, 2, pVSBlob->GetBufferPointer(), pVSBlob->GetBufferSize(), &m_pFullScreenLayout);
        pVSBlob->Release();
        if (FAILED(result))
            return result;
    }

    if (!m_pFullScreenQuadVB)
    {
        FullScreenVertex vertices[] =
        {
            { XMFLOAT3(-1.0f, -1.0f, 0.0f), XMFLOAT2(0.0f, 1.0f) },
            { XMFLOAT3(-1.0f,  1.0f, 0.0f), XMFLOAT2(0.0f, 0.0f) },
            { XMFLOAT3(1.0f, -1.0f, 0.0f), XMFLOAT2(1.0f, 1.0f) },
            { XMFLOAT3(1.0f,  1.0f, 0.0f), XMFLOAT2(1.0f, 0.0f) },
        };

        D3D11_BUFFER_DESC bd = {};
        bd.Usage = D3D11_USAGE_DEFAULT;
        bd.ByteWidth = sizeof(FullScreenVertex) * 4;
        bd.BindFlags = D3D11_BIND_VERTEX_BUFFER;

        D3D11_SUBRESOURCE_DATA initData = {};
        initData.pSysMem = vertices;

        result = m_pDevice->CreateBuffer(&bd, &initData, &m_pFullScreenQuadVB);
        if (FAILED(result))
            return result;
    }

    size = minDim;
    for (int i = 0; i < m_LuminanceLevels; i++)
    {
        UINT currentSize = (size < 1) ? 1 : size;

        D3D11_TEXTURE2D_DESC texDesc = {};
        texDesc.Width = currentSize;
        texDesc.Height = currentSize;
        texDesc.MipLevels = 1;
        texDesc.ArraySize = 1;
        texDesc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
        texDesc.SampleDesc.Count = 1;
        texDesc.Usage = D3D11_USAGE_DEFAULT;
        texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;

        result = m_pDevice->CreateTexture2D(&texDesc, nullptr, &m_pLuminanceTextures[i]);
        if (FAILED(result))
            return result;

        result = m_pDevice->CreateRenderTargetView(m_pLuminanceTextures[i], nullptr, &m_pLuminanceRTV[i]);
        if (FAILED(result))
            return result;

        result = m_pDevice->CreateShaderResourceView(m_pLuminanceTextures[i], nullptr, &m_pLuminanceSRV[i]);
        if (FAILED(result))
            return result;

        size /= 2;
    }

    size = minDim;
    for (int i = 0; i < m_LuminanceLevels; i++)
    {
        UINT currentSize = (size < 1) ? 1 : size;

        D3D11_TEXTURE2D_DESC stagingDesc = {};
        stagingDesc.Width = currentSize;
        stagingDesc.Height = currentSize;
        stagingDesc.MipLevels = 1;
        stagingDesc.ArraySize = 1;
        stagingDesc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
        stagingDesc.SampleDesc.Count = 1;
        stagingDesc.Usage = D3D11_USAGE_STAGING;
        stagingDesc.BindFlags = 0;
        stagingDesc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;

        result = m_pDevice->CreateTexture2D(&stagingDesc, nullptr, &m_pLuminanceStagingTextures[i]);
        if (FAILED(result))
            return result;

        size /= 2;
    }

    if (!m_pLuminanceQuery)
    {
        D3D11_QUERY_DESC queryDesc = {};
        queryDesc.Query = D3D11_QUERY_EVENT;
        result = m_pDevice->CreateQuery(&queryDesc, &m_pLuminanceQuery);
    }

    return result;
}

void RenderClass::CalculateAverageLuminance()
{
    if (!m_pDeviceContext || !m_pHDRSceneSRV)
        return;

    ID3D11RenderTargetView* pOldRTV = nullptr;
    ID3D11DepthStencilView* pOldDSV = nullptr;
    m_pDeviceContext->OMGetRenderTargets(1, &pOldRTV, &pOldDSV);

    D3D11_VIEWPORT oldViewport;
    UINT numViewports = 1;
    m_pDeviceContext->RSGetViewports(&numViewports, &oldViewport);

    ID3D11VertexShader* pOldVS = nullptr;
    ID3D11PixelShader* pOldPS = nullptr;
    ID3D11InputLayout* pOldLayout = nullptr;
    m_pDeviceContext->VSGetShader(&pOldVS, nullptr, nullptr);
    m_pDeviceContext->PSGetShader(&pOldPS, nullptr, nullptr);
    m_pDeviceContext->IAGetInputLayout(&pOldLayout);

    UINT stride = sizeof(FullScreenVertex);
    UINT offset = 0;
    m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pFullScreenQuadVB, &stride, &offset);
    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
    m_pDeviceContext->IASetInputLayout(m_pFullScreenLayout);

    m_pDeviceContext->VSSetShader(m_pFullScreenVS, nullptr, 0);
    m_pDeviceContext->PSSetShader(m_pLuminancePS, nullptr, 0);

    D3D11_VIEWPORT vp = {};
    D3D11_TEXTURE2D_DESC texDesc;
    m_pLuminanceTextures[0]->GetDesc(&texDesc);
    vp.Width = (FLOAT)texDesc.Width;
    vp.Height = (FLOAT)texDesc.Height;
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    vp.TopLeftX = 0;
    vp.TopLeftY = 0;

    m_pDeviceContext->OMSetRenderTargets(1, &m_pLuminanceRTV[0], nullptr);
    m_pDeviceContext->RSSetViewports(1, &vp);
    m_pDeviceContext->PSSetShaderResources(0, 1, &m_pHDRSceneSRV);
    m_pDeviceContext->Draw(4, 0);

    m_pDeviceContext->PSSetShader(m_pDownsamplePS, nullptr, 0);

    for (int i = 1; i < m_LuminanceLevels; i++)
    {
        m_pLuminanceTextures[i]->GetDesc(&texDesc);
        vp.Width = (FLOAT)texDesc.Width;
        vp.Height = (FLOAT)texDesc.Height;
        m_pDeviceContext->RSSetViewports(1, &vp);

        m_pDeviceContext->OMSetRenderTargets(1, &m_pLuminanceRTV[i], nullptr);
        m_pDeviceContext->PSSetShaderResources(0, 1, &m_pLuminanceSRV[i - 1]);
        m_pDeviceContext->Draw(4, 0);
    }

    ID3D11ShaderResourceView* nullSRV = nullptr;
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);

    m_pDeviceContext->OMSetRenderTargets(1, &pOldRTV, pOldDSV);
    m_pDeviceContext->RSSetViewports(1, &oldViewport);
    m_pDeviceContext->VSSetShader(pOldVS, nullptr, 0);
    m_pDeviceContext->PSSetShader(pOldPS, nullptr, 0);
    m_pDeviceContext->IASetInputLayout(pOldLayout);

    if (pOldVS)
        pOldVS->Release();
    if (pOldPS)
        pOldPS->Release();
    if (pOldLayout)
        pOldLayout->Release();
    if (pOldRTV)
        pOldRTV->Release();
    if (pOldDSV)
        pOldDSV->Release();

    if (m_pLuminanceQuery)
    {
        if (m_pDeviceContext->GetData(m_pLuminanceQuery, nullptr, 0, 0) != S_FALSE)
        {
            m_pDeviceContext->End(m_pLuminanceQuery);
        }
    }
}

float RenderClass::ReadLuminanceFromGPU()
{
    while (m_pDeviceContext->GetData(m_pLuminanceQuery, nullptr, 0, 0) == S_FALSE)
    {
        Sleep(1);
    }

    int lastLevel = m_LuminanceLevels - 1;

    m_pDeviceContext->CopyResource(m_pLuminanceStagingTextures[lastLevel], m_pLuminanceTextures[lastLevel]);

    D3D11_MAPPED_SUBRESOURCE mapped;
    HRESULT hr = m_pDeviceContext->Map(m_pLuminanceStagingTextures[lastLevel], 0, D3D11_MAP_READ, 0, &mapped);

    float luminance = 0.5f;
    if (SUCCEEDED(hr))
    {
        float logAvg = ((float*)mapped.pData)[0]; 
        luminance = expf(logAvg) - 1.0f; 
        m_pDeviceContext->Unmap(m_pLuminanceStagingTextures[lastLevel], 0);
    }

    return luminance;
}

void RenderClass::Terminate()
{
    if (ImGui::GetCurrentContext() != nullptr)
    {
        ShutdownImGui();
    }

    m_environmentFiles.clear();
    m_environmentFileNames.clear();

    ReleaseAllGltfModelResources();

    TerminateBufferShader();

    ReleaseGroundPlane();

    ReleaseShadowResources();

    if (m_pBRDFLUTSRV)
    {
        m_pBRDFLUTSRV->Release();
        m_pBRDFLUTSRV = nullptr;
    }
    if (m_pPrefilteredEnvSRV)
    {
        m_pPrefilteredEnvSRV->Release();
        m_pPrefilteredEnvSRV = nullptr;
    }

    for (int i = 0; i < 16; i++)
    {
        if (m_pLuminanceTextures[i])
        {
            m_pLuminanceTextures[i]->Release();
            m_pLuminanceTextures[i] = nullptr;
        }
        if (m_pLuminanceRTV[i])
        {
            m_pLuminanceRTV[i]->Release();
            m_pLuminanceRTV[i] = nullptr;
        }
        if (m_pLuminanceSRV[i])
        {
            m_pLuminanceSRV[i]->Release();
            m_pLuminanceSRV[i] = nullptr;
        }
        if (m_pLuminanceStagingTextures[i])
        {
            m_pLuminanceStagingTextures[i]->Release();
            m_pLuminanceStagingTextures[i] = nullptr;
        }
    }

    if (m_pLuminanceQuery)
    {
        if (m_pDeviceContext)
        {
            m_pDeviceContext->End(m_pLuminanceQuery);
            m_pDeviceContext->Flush();
        }
        m_pLuminanceQuery->Release();
        m_pLuminanceQuery = nullptr;
    }

    if (m_pFullScreenLayout)
    {
        m_pFullScreenLayout->Release();
        m_pFullScreenLayout = nullptr;
    }

    if (m_pHDRSceneSRV)
    {
        m_pHDRSceneSRV->Release();
        m_pHDRSceneSRV = nullptr;
    }

    if (m_pIrradianceSRV)
    {
        m_pIrradianceSRV->Release();
        m_pIrradianceSRV = nullptr;
    }

    if (m_pHDRSceneRTV)
    {
        m_pHDRSceneRTV->Release();
        m_pHDRSceneRTV = nullptr;
    }

    if (m_pHDRSceneTexture)
    {
        m_pHDRSceneTexture->Release();
        m_pHDRSceneTexture = nullptr;
    }

    if (m_pRenderTargetView)
    {
        m_pRenderTargetView->Release();
        m_pRenderTargetView = nullptr;
    }

    if (m_pDepthView)
    {
        m_pDepthView->Release();
        m_pDepthView = nullptr;
    }

    if (m_pSwapChain)
    {
        m_pSwapChain->Release();
        m_pSwapChain = nullptr;
    }

    if (m_pDeviceContext)
    {
        m_pDeviceContext->ClearState();
        m_pDeviceContext->Flush();
        m_pDeviceContext->Release();
        m_pDeviceContext = nullptr;
    }

    if (m_pAnnotation)
    {
        m_pAnnotation->Release();
        m_pAnnotation = nullptr;
    }

    if (m_pDevice)
    {
#ifdef _DEBUG
        ID3D11Debug* pDebug = nullptr;
        HRESULT hr = m_pDevice->QueryInterface(__uuidof(ID3D11Debug), (void**)&pDebug);
        if (SUCCEEDED(hr) && pDebug)
        {
            pDebug->ReportLiveDeviceObjects(D3D11_RLDO_DETAIL);
            pDebug->Release();
        }
#endif
        m_pDevice->Release();
        m_pDevice = nullptr;
    }
}

void RenderClass::TerminateBufferShader()
{
    if (m_pVertexShader)
    {
        m_pVertexShader->Release();
        m_pVertexShader = nullptr;
    }

    if (m_pPixelShader)
    {
        m_pPixelShader->Release();
        m_pPixelShader = nullptr;
    }

    if (m_pLightPixelShader)
    {
        m_pLightPixelShader->Release();
        m_pLightPixelShader = nullptr;
    }

    if (m_pFullScreenVS)
    {
        m_pFullScreenVS->Release();
        m_pFullScreenVS = nullptr;
    }

    if (m_pLuminancePS)
    {
        m_pLuminancePS->Release();
        m_pLuminancePS = nullptr;
    }

    if (m_pDownsamplePS)
    {
        m_pDownsamplePS->Release();
        m_pDownsamplePS = nullptr;
    }

    if (m_pToneMapPS)
    {
        m_pToneMapPS->Release();
        m_pToneMapPS = nullptr;
    }

    if (m_pIrradianceConvolutionPS)
    {
        m_pIrradianceConvolutionPS->Release();
        m_pIrradianceConvolutionPS = nullptr;
    }

    if (m_pLayout)
    {
        m_pLayout->Release();
        m_pLayout = nullptr;
    }

    if (m_pSkyLayout)
    {
        m_pSkyLayout->Release();
        m_pSkyLayout = nullptr;
    }

    if (m_pFullScreenLayout)
    {
        m_pFullScreenLayout->Release();
        m_pFullScreenLayout = nullptr;
    }

    if (m_pVertexBuffer)
    {
        m_pVertexBuffer->Release();
        m_pVertexBuffer = nullptr;
    }

    if (m_pIndexBuffer)
    {
        m_pIndexBuffer->Release();
        m_pIndexBuffer = nullptr;
    }

    if (m_pFullScreenQuadVB)
    {
        m_pFullScreenQuadVB->Release();
        m_pFullScreenQuadVB = nullptr;
    }

    if (m_pModelBuffer)
    {
        m_pModelBuffer->Release();
        m_pModelBuffer = nullptr;
    }

    if (m_pVPBuffer)
    {
        m_pVPBuffer->Release();
        m_pVPBuffer = nullptr;
    }

    if (m_pLightBuffer)
    {
        m_pLightBuffer->Release();
        m_pLightBuffer = nullptr;
    }

    if (m_pMaterialBuffer)
    {
        m_pMaterialBuffer->Release();
        m_pMaterialBuffer = nullptr;
    }

    if (m_pColorBuffer)
    {
        m_pColorBuffer->Release();
        m_pColorBuffer = nullptr;
    }

    if (m_pToneMapCB)
    {
        m_pToneMapCB->Release();
        m_pToneMapCB = nullptr;
    }

    if (m_pEnvironmentSRV) 
    {
        m_pEnvironmentSRV->Release();
        m_pEnvironmentSRV = nullptr;
    }

    if (m_pSkyVertexShader) 
    {
        m_pSkyVertexShader->Release();
        m_pSkyVertexShader = nullptr;
    }

    if (m_pSkyPixelShader) 
    {
        m_pSkyPixelShader->Release();
        m_pSkyPixelShader = nullptr;
    }

    if (m_pSkyRasterState) 
    {
        m_pSkyRasterState->Release();
        m_pSkyRasterState = nullptr;
    }

    if (m_pGltfRasterState)
    {
        m_pGltfRasterState->Release();
        m_pGltfRasterState = nullptr;
    }

    if (m_pSkyDepthState) 
    {
        m_pSkyDepthState->Release();
        m_pSkyDepthState = nullptr;
    }

    for (int i = 0; i < kSphereCount; ++i)
    {
        if (m_pTextureViews[i])
        {
            m_pTextureViews[i]->Release();
            m_pTextureViews[i] = nullptr;
        }
        if (m_pNormalMapViews[i])
        {
            m_pNormalMapViews[i]->Release();
            m_pNormalMapViews[i] = nullptr;
        }
    }

    if (m_pSamplerState)
    {
        m_pSamplerState->Release();
        m_pSamplerState = nullptr;
    }

    if (m_pHdrToCubemapPS)
    {
        m_pHdrToCubemapPS->Release();
        m_pHdrToCubemapPS = nullptr;
    }

    if (m_pPrefilteredEnvSRV)
    {
        m_pPrefilteredEnvSRV->Release();
        m_pPrefilteredEnvSRV = nullptr;
    }

    if (m_pSpecularPrefilterPS)
    {
        m_pSpecularPrefilterPS->Release();
        m_pSpecularPrefilterPS = nullptr;
    }

    if (m_pSpecularPrefilterCB)
    {
        m_pSpecularPrefilterCB->Release();
        m_pSpecularPrefilterCB = nullptr;
    }

    if (m_pSpecularPrefilterPS)
    {
        m_pSpecularPrefilterPS->Release();
        m_pSpecularPrefilterPS = nullptr;
    }
    if (m_pBRDFIntegrationPS)
    {
        m_pBRDFIntegrationPS->Release();
        m_pBRDFIntegrationPS = nullptr;
    }

    if (m_pBloomExtractPS) 
    { 
        m_pBloomExtractPS->Release(); 
        m_pBloomExtractPS = nullptr; 
    }

    if (m_pBloomBlurPS) 
    { 
        m_pBloomBlurPS->Release(); 
        m_pBloomBlurPS = nullptr; 
    }

    if (m_pBloomCB) 
    { 
        m_pBloomCB->Release(); 
        m_pBloomCB = nullptr; 
    }

    ReleaseBloomResources();
}

std::wstring Extension(const std::wstring& path)
{
    size_t dotPos = path.find_last_of(L".");
    if (dotPos == std::wstring::npos || dotPos == 0)
    {
        return L"";
    }
    return path.substr(dotPos + 1);
}

HRESULT RenderClass::CompileShader(const std::wstring& path, ID3D11VertexShader** ppVertexShader, ID3D11PixelShader** ppPixelShader, ID3DBlob** pCodeShader)
{
    std::wstring extension = Extension(path);

    std::string platform = "";

    if (extension == L"vs")
    {
        platform = "vs_5_0";
    }
    else if (extension == L"ps")
    {
        platform = "ps_5_0";
    }

    UINT flags = 0;
#ifdef _DEBUG
    flags |= D3DCOMPILE_DEBUG | D3DCOMPILE_SKIP_OPTIMIZATION;
#endif 

    ID3DBlob* pCode = nullptr;
    ID3DBlob* pErr = nullptr;

    HRESULT result = D3DCompileFromFile(path.c_str(), nullptr, D3D_COMPILE_STANDARD_FILE_INCLUDE, "main", platform.c_str(), 0, 0, &pCode, &pErr);
    if (!SUCCEEDED(result) && pErr != nullptr)
    {
        OutputDebugStringA((const char*)pErr->GetBufferPointer());
    }
    if (pErr)
        pErr->Release();

    if (SUCCEEDED(result))
    {
        if (extension == L"vs" && ppVertexShader)
        {
            result = m_pDevice->CreateVertexShader(pCode->GetBufferPointer(), pCode->GetBufferSize(), nullptr, ppVertexShader);
            if (FAILED(result))
            {
                pCode->Release();
                return result;
            }
        }
        else if (extension == L"ps" && ppPixelShader)
        {
            result = m_pDevice->CreatePixelShader(pCode->GetBufferPointer(), pCode->GetBufferSize(), nullptr, ppPixelShader);
            if (FAILED(result))
            {
                pCode->Release();
                return result;
            }
        }
    }

    if (pCodeShader)
    {
        *pCodeShader = pCode;
    }
    else
    {
        pCode->Release();
    }
    return result;
}

HRESULT RenderClass::LoadHDRTexture2D(const wchar_t* path, ID3D11ShaderResourceView** outSRV)
{
    if (!outSRV)
        return E_INVALIDARG;
    *outSRV = nullptr;
    std::string narrowPath(path, path + wcslen(path));
    int width = 0;
    int height = 0;
    int channels = 0;
    float* data = stbi_loadf(narrowPath.c_str(), &width, &height, &channels, 3);
    if (!data)
        return E_FAIL;
    std::vector<float> rgba(width * height * 4);
    for (int i = 0; i < width * height; ++i)
    {
        rgba[i * 4 + 0] = data[i * 3 + 0];
        rgba[i * 4 + 1] = data[i * 3 + 1];
        rgba[i * 4 + 2] = data[i * 3 + 2];
        rgba[i * 4 + 3] = 1.0f;
    }
    stbi_image_free(data);
    D3D11_TEXTURE2D_DESC desc = {};
    desc.Width = static_cast<UINT>(width);
    desc.Height = static_cast<UINT>(height);
    desc.MipLevels = 1;
    desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_R32G32B32A32_FLOAT;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
    D3D11_SUBRESOURCE_DATA initData = {};
    initData.pSysMem = rgba.data();
    initData.SysMemPitch = width * sizeof(float) * 4;
    ID3D11Texture2D* tex = nullptr;
    HRESULT hr = m_pDevice->CreateTexture2D(&desc, &initData, &tex);
    if (FAILED(hr))
        return hr;
    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
    srvDesc.Format = desc.Format;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = 1;
    hr = m_pDevice->CreateShaderResourceView(tex, &srvDesc, outSRV);
    tex->Release();
    return hr;
}

HRESULT RenderClass::ConvertHDRIToCubemap(
    ID3D11ShaderResourceView* equirectSRV,
    UINT cubeSize,
    ID3D11ShaderResourceView** outCubeSRV)
{
    if (!equirectSRV || !outCubeSRV)
        return E_INVALIDARG;

    UINT oldViewportCount = 1;
    D3D11_VIEWPORT oldViewport = {};
    m_pDeviceContext->RSGetViewports(&oldViewportCount, &oldViewport);

    ID3D11RenderTargetView* oldRTV = nullptr;
    ID3D11DepthStencilView* oldDSV = nullptr;
    m_pDeviceContext->OMGetRenderTargets(1, &oldRTV, &oldDSV);

    *outCubeSRV = nullptr;
    D3D11_TEXTURE2D_DESC cubeDesc = {};
    cubeDesc.Width = cubeSize;
    cubeDesc.Height = cubeSize;
    cubeDesc.MipLevels = 0; 
    cubeDesc.ArraySize = 6;
    cubeDesc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
    cubeDesc.SampleDesc.Count = 1;
    cubeDesc.Usage = D3D11_USAGE_DEFAULT;
    cubeDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
    cubeDesc.MiscFlags = D3D11_RESOURCE_MISC_TEXTURECUBE | D3D11_RESOURCE_MISC_GENERATE_MIPS;

    ID3D11Texture2D* cubeTex = nullptr;
    HRESULT hr = m_pDevice->CreateTexture2D(&cubeDesc, nullptr, &cubeTex);
    if (FAILED(hr))
        return hr;

    D3D11_TEXTURE2D_DESC verifyDesc = {};
    cubeTex->GetDesc(&verifyDesc);

    wchar_t dbg[256];
    swprintf_s(
        dbg,
        L"CubeTex: %u x %u, ArraySize=%u, Mips=%u, MiscFlags=%u\n",
        verifyDesc.Width,
        verifyDesc.Height,
        verifyDesc.ArraySize,
        verifyDesc.MipLevels,
        verifyDesc.MiscFlags
    );
    OutputDebugString(dbg);

    D3D11_SHADER_RESOURCE_VIEW_DESC cubeSRVDesc = {};
    cubeSRVDesc.Format = cubeDesc.Format;
    cubeSRVDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURECUBE;
    cubeSRVDesc.TextureCube.MostDetailedMip = 0;
    cubeSRVDesc.TextureCube.MipLevels = -1;

    ID3D11ShaderResourceView* cubeSRV = nullptr;
    hr = m_pDevice->CreateShaderResourceView(cubeTex, &cubeSRVDesc, &cubeSRV);
    if (FAILED(hr))
    {
        cubeTex->Release();
        return hr;
    }

    ID3D11RenderTargetView* faceRTV[6] = {};
    for (UINT i = 0; i < 6; ++i)
    {
        D3D11_RENDER_TARGET_VIEW_DESC rtvDesc = {};
        rtvDesc.Format = cubeDesc.Format;
        rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DARRAY;
        rtvDesc.Texture2DArray.MipSlice = 0;
        rtvDesc.Texture2DArray.FirstArraySlice = i;
        rtvDesc.Texture2DArray.ArraySize = 1;

        hr = m_pDevice->CreateRenderTargetView(cubeTex, &rtvDesc, &faceRTV[i]);
        if (FAILED(hr))
        {
            for (UINT k = 0; k < i; ++k)
                if (faceRTV[k]) 
                    faceRTV[k]->Release();
            cubeSRV->Release();
            cubeTex->Release();
            return hr;
        }
    }

    ID3D11RasterizerState* pOldRS = nullptr;
    m_pDeviceContext->RSGetState(&pOldRS);

    D3D11_RASTERIZER_DESC rsDesc = {};
    rsDesc.FillMode = D3D11_FILL_SOLID;
    rsDesc.CullMode = D3D11_CULL_FRONT;
    rsDesc.FrontCounterClockwise = FALSE;
    rsDesc.DepthClipEnable = TRUE;

    ID3D11RasterizerState* pCubeRS = nullptr;
    hr = m_pDevice->CreateRasterizerState(&rsDesc, &pCubeRS);
    if (FAILED(hr))
    {
        for (UINT i = 0; i < 6; ++i) 
            faceRTV[i]->Release();
        cubeSRV->Release();
        cubeTex->Release();
        if (pOldRS) 
            pOldRS->Release();
        return hr;
    }
    m_pDeviceContext->RSSetState(pCubeRS);

    D3D11_VIEWPORT vp = {};
    vp.TopLeftX = 0.0f;
    vp.TopLeftY = 0.0f;
    vp.Width = static_cast<float>(cubeSize);
    vp.Height = static_cast<float>(cubeSize);
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    m_pDeviceContext->RSSetViewports(1, &vp);

    UINT stride = sizeof(CubeVertex);
    UINT offset = 0;
    m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pVertexBuffer, &stride, &offset);
    m_pDeviceContext->IASetIndexBuffer(m_pIndexBuffer, DXGI_FORMAT_R16_UINT, 0);
    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    m_pDeviceContext->IASetInputLayout(m_pSkyLayout);

    m_pDeviceContext->VSSetShader(m_pSkyVertexShader, nullptr, 0);
    m_pDeviceContext->PSSetShader(m_pHdrToCubemapPS, nullptr, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &equirectSRV);
    m_pDeviceContext->PSSetSamplers(0, 1, &m_pSamplerState);

    m_pDeviceContext->VSSetConstantBuffers(0, 1, &m_pModelBuffer);
    m_pDeviceContext->VSSetConstantBuffers(1, 1, &m_pVPBuffer);

    XMMATRIX proj = XMMatrixPerspectiveFovLH(XM_PIDIV2, 1.0f, 0.1f, 10.0f);
    XMVECTOR eye = XMVectorZero();
    const XMVECTOR targets[6] =
    {
        XMVectorSet(1, 0, 0, 0),
        XMVectorSet(-1, 0, 0, 0),
        XMVectorSet(0, 1, 0, 0),
        XMVectorSet(0, -1, 0, 0),
        XMVectorSet(0, 0, 1, 0),
        XMVectorSet(0, 0, -1, 0)
    };
    const XMVECTOR ups[6] =
    {
        XMVectorSet(0, 1, 0, 0),
        XMVectorSet(0, 1, 0, 0),
        XMVectorSet(0, 0, -1, 0),
        XMVectorSet(0, 0, 1, 0),
        XMVectorSet(0, 1, 0, 0),
        XMVectorSet(0, 1, 0, 0)
    };
    XMMATRIX model = XMMatrixIdentity();
    XMMATRIX modelT = XMMatrixTranspose(model);
    m_pDeviceContext->UpdateSubresource(m_pModelBuffer, 0, nullptr, &modelT, 0, 0);

    for (UINT face = 0; face < 6; ++face)
    {
        float clearColor[4] = { 0, 0, 0, 1 };
        m_pDeviceContext->OMSetRenderTargets(1, &faceRTV[face], nullptr);
        m_pDeviceContext->ClearRenderTargetView(faceRTV[face], clearColor);
        CameraBuffer cb = {};
        cb.vp = XMMatrixTranspose(XMMatrixLookToLH(eye, targets[face], ups[face]) * proj);
        cb.cameraPos = XMFLOAT3(0, 0, 0);
        D3D11_MAPPED_SUBRESOURCE mapped = {};
        hr = m_pDeviceContext->Map(m_pVPBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
        if (FAILED(hr))
            break;
        memcpy(mapped.pData, &cb, sizeof(cb));
        m_pDeviceContext->Unmap(m_pVPBuffer, 0);
        m_pDeviceContext->DrawIndexed(m_indexCount, 0, 0);
    }

    ID3D11ShaderResourceView* nullSRV = nullptr;
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);
    
    if (SUCCEEDED(hr))
        m_pDeviceContext->GenerateMips(cubeSRV);

    m_pDeviceContext->RSSetState(pOldRS);
    if (pOldRS) 
        pOldRS->Release();
    if (pCubeRS) 
        pCubeRS->Release();

    for (UINT i = 0; i < 6; ++i)
        if (faceRTV[i])
            faceRTV[i]->Release();
    cubeTex->Release();

    if (FAILED(hr))
    {
        cubeSRV->Release();
        return hr;
    }
    *outCubeSRV = cubeSRV;

    m_pDeviceContext->OMSetRenderTargets(1, &oldRTV, oldDSV);
    m_pDeviceContext->RSSetViewports(1, &oldViewport);

    if (oldRTV) 
        oldRTV->Release();
    if (oldDSV) 
        oldDSV->Release();

    return S_OK;
}

HRESULT RenderClass::LoadEnvironmentMap(const wchar_t* path)
{
    if (m_pEnvironmentSRV)
    {
        m_pEnvironmentSRV->Release();
        m_pEnvironmentSRV = nullptr;
    }
    if (m_pIrradianceSRV)
    {
        m_pIrradianceSRV->Release();
        m_pIrradianceSRV = nullptr;
    }
    if (m_pPrefilteredEnvSRV)
    {
        m_pPrefilteredEnvSRV->Release();
        m_pPrefilteredEnvSRV = nullptr;
    }
    HRESULT hr = E_FAIL;
    if (HasExtension(path, L".dds"))
    {
        hr = DirectX::CreateDDSTextureFromFileEx(
            m_pDevice,
            path,
            0,
            D3D11_USAGE_DEFAULT,
            D3D11_BIND_SHADER_RESOURCE,
            0,
            0,
            DirectX::DDS_LOADER_FORCE_SRGB,
            nullptr,
            &m_pEnvironmentSRV
            );
    }
    else if (HasExtension(path, L".hdr"))
    {
        ID3D11ShaderResourceView* hdr2DSRV = nullptr;
        hr = LoadHDRTexture2D(path, &hdr2DSRV);
        if (FAILED(hr))
            return hr;
        hr = ConvertHDRIToCubemap(hdr2DSRV, 1024, &m_pEnvironmentSRV);
        hdr2DSRV->Release();
    }
    if (FAILED(hr))
        return hr;

    hr = ConvolveCubemapToIrradiance(
        m_pEnvironmentSRV,
        32,
        &m_pIrradianceSRV
    );
    if (FAILED(hr))
        return hr;

    hr = PrefilterCubemapSpecular(
        m_pEnvironmentSRV,
        256,
        5,
        &m_pPrefilteredEnvSRV
    );
    if (FAILED(hr))
        return hr;

    return S_OK;
}

void RenderClass::ScanCubeMapsFolder()
{
    m_environmentFiles.clear();
    m_environmentFileNames.clear();

    std::filesystem::path folder(L"cubemaps");
    if (!std::filesystem::exists(folder))
        return;

    for (const auto& entry : std::filesystem::directory_iterator(folder))
    {
        if (entry.is_regular_file())
        {
            auto ext = ToLowerCopy(entry.path().extension().wstring());
            if (ext == L".hdr")
            {
                m_environmentFiles.push_back(entry.path().wstring());
                m_environmentFileNames.push_back(entry.path().filename().string());
            }
        }
    }
}

void RenderClass::Render()
{
    struct ScopedEvent
    {
        ID3DUserDefinedAnnotation* ann = nullptr;
        bool active = false;

        ScopedEvent(ID3DUserDefinedAnnotation* a, const wchar_t* name) : ann(a)
        {
            if (ann && ann->GetStatus())
            {
                ann->BeginEvent(name);
                active = true;
            }
        }

        ~ScopedEvent()
        {
            if (active && ann)
                ann->EndEvent();
        }
    };

    ScopedEvent frameEvent(m_pAnnotation, L"Frame");

    {
        ScopedEvent evt(m_pAnnotation, L"Clear");

        UpdateShadowBufferData();

        ID3D11RenderTargetView* sceneRTV = (m_DebugViewMode == DebugView_Final) ? m_pHDRSceneRTV : m_pRenderTargetView;
        m_pDeviceContext->OMSetRenderTargets(1, &sceneRTV, m_pDepthView);

        
        float hdrClear[4] = { 0, 0, 0, 0 };
        if (m_DebugViewMode == DebugView_Final)
        {
            float BackColor[4] = { 0.48f, 0.57f, 0.48f, 1.0f };
            m_pDeviceContext->ClearRenderTargetView(m_pRenderTargetView, BackColor);

            if (m_pHDRSceneRTV)
                m_pDeviceContext->ClearRenderTargetView(m_pHDRSceneRTV, hdrClear);
        }
        else
        {
            m_pDeviceContext->ClearRenderTargetView(m_pRenderTargetView, hdrClear);
        }
        m_pDeviceContext->ClearDepthStencilView(m_pDepthView, D3D11_CLEAR_DEPTH, 1.0f, 0);
    }

    RECT rc;
    GetClientRect(FindWindow(m_szWindowClass, m_szTitle), &rc);

    D3D11_VIEWPORT vp = {};
    vp.Width = (FLOAT)(rc.right - rc.left);
    vp.Height = (FLOAT)(rc.bottom - rc.top);
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    m_pDeviceContext->RSSetViewports(1, &vp);
    RenderShadowPass();

    float aspect = static_cast<float>(rc.right - rc.left) / (rc.bottom - rc.top);
    XMMATRIX viewProj = BuildViewProjMatrix(
        m_CameraPosition,
        m_LRAngle,
        m_UDAngle,
        aspect
    );

    UpdateCameraAndLightBuffers(viewProj);
    RenderSkybox(viewProj);

    RenderGroundPlane(viewProj);
    RenderAllSceneModels(viewProj);

    RenderLightSources(viewProj);

    if (m_DebugViewMode == DebugView_Final)
        ApplyBloom();

    if (m_DebugViewMode == DebugView_Final)
    {
        {
            ScopedEvent evt(m_pAnnotation, L"Luminance Calculation");
            CalculateAverageLuminance();
            m_CurrentLuminance = ReadLuminanceFromGPU();
            static int frameCount = 0;
            frameCount++;
            if (frameCount % 20 == 0)
            {
                char buf[256];
                sprintf_s(buf, "CurrLum=%.4f AdaptLum=%.4f\n", m_CurrentLuminance, m_AdaptedLuminance);
                OutputDebugStringA(buf);
            }
            ULONGLONG now = GetTickCount64();
            float dt = (m_LastFrameTime == 0) ? (1.0f / 60.0f)
                : float(now - m_LastFrameTime) / 10.0f;
            m_LastFrameTime = now;
            if (dt > 0.1f) dt = 0.1f;
            float tauUp = 1.5f;
            float tauDown = 1.5f;
            float tau = (m_CurrentLuminance > m_AdaptedLuminance) ? tauUp : tauDown;
            float k = 1.0f - expf(-dt / tau);
            m_AdaptedLuminance += (m_CurrentLuminance - m_AdaptedLuminance) * k;
        }

        {
            ScopedEvent evt(m_pAnnotation, L"Apply tone mapping");
            ApplyToneMapping();
        }
    }

    {
        ScopedEvent evt(m_pAnnotation, L"ImGui");
        RenderImGui();
    }

    {
        ScopedEvent evt(m_pAnnotation, L"Present");
        m_pSwapChain->Present(1, 0);
    }
}

void RenderClass::UpdateCameraAndLightBuffers(const XMMATRIX& viewProj)
{
    CameraBuffer cameraBuffer = {};
    cameraBuffer.vp = XMMatrixTranspose(viewProj);
    cameraBuffer.cameraPos = m_CameraPosition;
    D3D11_MAPPED_SUBRESOURCE mappedResource;
    HRESULT hr = m_pDeviceContext->Map(m_pVPBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
    if (SUCCEEDED(hr))
    {
        memcpy(mappedResource.pData, &cameraBuffer, sizeof(CameraBuffer));
        m_pDeviceContext->Unmap(m_pVPBuffer, 0);
    }

    m_pDeviceContext->VSSetConstantBuffers(1, 1, &m_pVPBuffer);

    PointLight lights[3];
    const float range = 150.0f; 
    const float baseIntensity = 200.0f;

    lights[0].Position = m_LightPositions[0];
    lights[0].Range = range;
    lights[0].Color = m_LightColors[0];
    lights[0].Intensity = m_LightBrightness[0] * baseIntensity;
    lights[1].Position = m_LightPositions[1];
    lights[1].Range = range;
    lights[1].Color = m_LightColors[1];
    lights[1].Intensity = m_LightBrightness[1] * baseIntensity;
    lights[2].Position = m_LightPositions[2];
    lights[2].Range = range;
    lights[2].Color = m_LightColors[2];
    lights[2].Intensity = m_LightBrightness[2] * baseIntensity;

    D3D11_MAPPED_SUBRESOURCE mappedLight;
    hr = m_pDeviceContext->Map(m_pLightBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedLight);
    if (SUCCEEDED(hr))
    {
        memcpy(mappedLight.pData, lights, sizeof(lights));
        m_pDeviceContext->Unmap(m_pLightBuffer, 0);
    }
    m_pDeviceContext->PSSetConstantBuffers(2, 1, &m_pLightBuffer);
}

void RenderClass::RenderSkybox(const XMMATRIX& viewProj)
{
    XMMATRIX skyModel =
        XMMatrixScaling(40.0f, 40.0f, 40.0f) *
        XMMatrixTranslation(m_CameraPosition.x, m_CameraPosition.y, m_CameraPosition.z);

    XMMATRIX skyModelT = XMMatrixTranspose(skyModel);

    m_pDeviceContext->UpdateSubresource(m_pModelBuffer, 0, nullptr, &skyModelT, 0, 0);
    m_pDeviceContext->VSSetConstantBuffers(0, 1, &m_pModelBuffer);
    m_pDeviceContext->VSSetConstantBuffers(1, 1, &m_pVPBuffer);
    m_pDeviceContext->RSSetState(m_pSkyRasterState);
    m_pDeviceContext->OMSetDepthStencilState(m_pSkyDepthState, 0);

    UINT stride = sizeof(CubeVertex);
    UINT offset = 0;
    m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pVertexBuffer, &stride, &offset);

    m_pDeviceContext->IASetIndexBuffer(m_pIndexBuffer, DXGI_FORMAT_R16_UINT, 0);
    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    m_pDeviceContext->IASetInputLayout(m_pSkyLayout);
    m_pDeviceContext->VSSetShader(m_pSkyVertexShader, nullptr, 0);
    m_pDeviceContext->PSSetShader(m_pSkyPixelShader, nullptr, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &m_pEnvironmentSRV);
    m_pDeviceContext->PSSetSamplers(0, 1, &m_pSamplerState);
    m_pDeviceContext->DrawIndexed(m_indexCount, 0, 0);

    ID3D11ShaderResourceView* nullSRV = nullptr;
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);
    m_pDeviceContext->RSSetState(nullptr);
    m_pDeviceContext->OMSetDepthStencilState(nullptr, 0);
}

HRESULT RenderClass::ConfigureBackBuffer(UINT width, UINT height)
{
    ID3D11Texture2D* pBackBuffer = nullptr;
    HRESULT hr = m_pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer);
    if (FAILED(hr))
        return hr;

    hr = m_pDevice->CreateRenderTargetView(pBackBuffer, nullptr, &m_pRenderTargetView);
    pBackBuffer->Release();
    if (FAILED(hr))
        return hr;

    D3D11_TEXTURE2D_DESC descDepth = {};
    descDepth.Width = width;
    descDepth.Height = height;
    descDepth.MipLevels = 1;
    descDepth.ArraySize = 1;
    descDepth.Format = DXGI_FORMAT_D32_FLOAT;
    descDepth.SampleDesc.Count = 1;
    descDepth.SampleDesc.Quality = 0;
    descDepth.BindFlags = D3D11_BIND_DEPTH_STENCIL;
    ID3D11Texture2D* pDepthStencil = nullptr;
    hr = m_pDevice->CreateTexture2D(&descDepth, nullptr, &pDepthStencil);
    if (FAILED(hr))
        return hr;

    hr = m_pDevice->CreateDepthStencilView(pDepthStencil, nullptr, &m_pDepthView);
    pDepthStencil->Release();
    if (FAILED(hr))
        return hr;

    return hr;
}

HRESULT RenderClass::CreateHDRSceneTexture(UINT width, UINT height)
{
    HRESULT hr;

    if (m_pHDRSceneSRV)
        m_pHDRSceneSRV->Release();
    if (m_pHDRSceneRTV)
        m_pHDRSceneRTV->Release();
    if (m_pHDRSceneTexture)
        m_pHDRSceneTexture->Release();

    D3D11_TEXTURE2D_DESC texDesc = {};
    texDesc.Width = width;
    texDesc.Height = height;
    texDesc.MipLevels = 1;
    texDesc.ArraySize = 1;
    texDesc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
    //texDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
    texDesc.SampleDesc.Count = 1;
    texDesc.Usage = D3D11_USAGE_DEFAULT;
    texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;

    hr = m_pDevice->CreateTexture2D(&texDesc, nullptr, &m_pHDRSceneTexture);
    if (FAILED(hr))
        return hr;

    hr = m_pDevice->CreateRenderTargetView(m_pHDRSceneTexture, nullptr, &m_pHDRSceneRTV);
    if (FAILED(hr))
        return hr;

    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
    srvDesc.Format = texDesc.Format;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = 1;

    hr = m_pDevice->CreateShaderResourceView(m_pHDRSceneTexture, &srvDesc, &m_pHDRSceneSRV);

    return hr;
}

// ground plane

HRESULT RenderClass::CreateGroundPlane(float halfSize, float uvScale)
{
    ReleaseGroundPlane();

    GroundVertex vertices[] =
    {
        { XMFLOAT3(-halfSize, 0.0f, -halfSize), XMFLOAT3(0, 1, 0), XMFLOAT2(0.0f, 0.0f) },
        { XMFLOAT3(-halfSize, 0.0f,  halfSize), XMFLOAT3(0, 1, 0), XMFLOAT2(0.0f, uvScale) },
        { XMFLOAT3(halfSize, 0.0f,  halfSize), XMFLOAT3(0, 1, 0), XMFLOAT2(uvScale, uvScale) },
        { XMFLOAT3(halfSize, 0.0f, -halfSize), XMFLOAT3(0, 1, 0), XMFLOAT2(uvScale, 0.0f) },
    };

    uint32_t indices[] = { 0, 1, 2, 0, 2, 3 };
    m_GroundIndexCount = _countof(indices);

    D3D11_BUFFER_DESC vbDesc = {};
    vbDesc.Usage = D3D11_USAGE_DEFAULT;
    vbDesc.ByteWidth = sizeof(vertices);
    vbDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;

    D3D11_SUBRESOURCE_DATA vbData = {};
    vbData.pSysMem = vertices;

    HRESULT hr = m_pDevice->CreateBuffer(&vbDesc, &vbData, &m_pGroundVB);
    if (FAILED(hr))
        return hr;

    D3D11_BUFFER_DESC ibDesc = {};
    ibDesc.Usage = D3D11_USAGE_DEFAULT;
    ibDesc.ByteWidth = sizeof(indices);
    ibDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;

    D3D11_SUBRESOURCE_DATA ibData = {};
    ibData.pSysMem = indices;

    hr = m_pDevice->CreateBuffer(&ibDesc, &ibData, &m_pGroundIB);
    if (FAILED(hr))
        return hr;

    return S_OK;
}

void RenderClass::RenderGroundPlane(const XMMATRIX& viewProj)
{
    if (!m_pGroundVB || !m_pGroundIB || m_GroundIndexCount == 0)
        return;

    UINT stride = sizeof(GroundVertex);
    UINT offset = 0;

    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    m_pDeviceContext->IASetInputLayout(m_pLayout);
    m_pDeviceContext->VSSetShader(m_pVertexShader, nullptr, 0);
    m_pDeviceContext->PSSetShader(m_pPixelShader, nullptr, 0);
    m_pDeviceContext->PSSetSamplers(0, 1, &m_pSamplerState);

    XMMATRIX world = XMMatrixIdentity();
    XMMATRIX worldT = XMMatrixTranspose(world);

    m_pDeviceContext->UpdateSubresource(m_pModelBuffer, 0, nullptr, &worldT, 0, 0);
    m_pDeviceContext->VSSetConstantBuffers(0, 1, &m_pModelBuffer);
    m_pDeviceContext->VSSetConstantBuffers(1, 1, &m_pVPBuffer);

    MaterialParamsCB materialParams = {};
    materialParams.Surface = XMFLOAT4(
        0.05f, // metallic
        0.40f, // roughness
        1.0f, // ao
        0.0f // normal strength
    ); 

    materialParams.Albedo = XMFLOAT4(1.0f, 1.0f, 1.0f, 1.0f);
    materialParams.DebugView = XMFLOAT4(
        (float)m_DebugViewMode,
        m_EnableSpecularIBL ? 1.0f : 0.0f,
        m_DiffuseIBLIntensity,
        m_SpecularIBLIntensity
    );
    materialParams.Emissive = XMFLOAT4(0, 0, 0, 0);
    m_pDeviceContext->UpdateSubresource(m_pMaterialBuffer, 0, nullptr, &materialParams, 0, 0);
    m_pDeviceContext->PSSetConstantBuffers(3, 1, &m_pMaterialBuffer);
    
    ID3D11ShaderResourceView* groundDiffuseSRV = m_pTextureViews[3];
    ID3D11ShaderResourceView* nullSRV = nullptr;
    m_pDeviceContext->PSSetShaderResources(0, 1, &groundDiffuseSRV); 
    m_pDeviceContext->PSSetShaderResources(1, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(2, 1, &m_pIrradianceSRV); 
    m_pDeviceContext->PSSetShaderResources(3, 1, &m_pPrefilteredEnvSRV); 
    m_pDeviceContext->PSSetShaderResources(4, 1, &m_pBRDFLUTSRV);
    m_pDeviceContext->PSSetShaderResources(5, 1, &nullSRV);

    m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pGroundVB, &stride, &offset);
    m_pDeviceContext->IASetIndexBuffer(m_pGroundIB, DXGI_FORMAT_R32_UINT, 0);
    
    m_pDeviceContext->VSSetConstantBuffers(4, 1, &m_pShadowLightBuffer);
    m_pDeviceContext->PSSetConstantBuffers(4, 1, &m_pShadowParamsBuffer);
    m_pDeviceContext->PSSetShaderResources(6, 1, &m_pShadowMapSRV);
    m_pDeviceContext->PSSetSamplers(1, 1, &m_pShadowSampler);
    m_pDeviceContext->PSSetSamplers(2, 1, &m_pShadowSampler);
    
    m_pDeviceContext->DrawIndexed(m_GroundIndexCount, 0, 0);
}

void RenderClass::ReleaseGroundPlane()
{
    if (m_pGroundVB)
    {
        m_pGroundVB->Release();
        m_pGroundVB = nullptr;
    }

    if (m_pGroundIB)
    {
        m_pGroundIB->Release();
        m_pGroundIB = nullptr;
    }

    m_GroundIndexCount = 0;
}

void RenderClass::BuildSceneLayout()
{
    m_SceneModelInstances.clear();

    const std::vector<SceneModelDesc> descs = GetSceneModelDescs();

    const size_t count = std::min(descs.size(), m_ModelResources.size());

    for (size_t i = 0; i < count; ++i)
    {
        SceneModelInstance inst = {};
        inst.ModelResourceIndex = (int)i;
        inst.Position = descs[i].Position;
        inst.RotationDeg = descs[i].RotationDeg;
        inst.Scale = descs[i].Scale;
        inst.CastShadow = descs[i].CastShadow;
        inst.ReceiveShadow = descs[i].ReceiveShadow;

        m_SceneModelInstances.push_back(inst);
    }
}

void RenderClass::PrecomputeSceneModelTransforms()
{
    for (SceneModelInstance& inst : m_SceneModelInstances)
    {
        const float rx = XMConvertToRadians(inst.RotationDeg.x);
        const float ry = XMConvertToRadians(inst.RotationDeg.y);
        const float rz = XMConvertToRadians(inst.RotationDeg.z);

        XMMATRIX scaleM =
            XMMatrixScaling(inst.Scale.x, inst.Scale.y, inst.Scale.z);

        XMMATRIX rotM =
            XMMatrixRotationRollPitchYaw(rx, ry, rz);

        XMMATRIX transM =
            XMMatrixTranslation(inst.Position.x, inst.Position.y, inst.Position.z);

        inst.PrecomputedWorld = scaleM * rotM * transM;
    }
}

// light

void RenderClass::RenderLightSources(const XMMATRIX& viewProj)
{
    UINT stride = sizeof(CubeVertex);
    UINT offset = 0;

    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    m_pDeviceContext->IASetInputLayout(m_pLayout);
    m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pVertexBuffer, &stride, &offset);
    m_pDeviceContext->IASetIndexBuffer(m_pIndexBuffer, DXGI_FORMAT_R16_UINT, 0);
    
    m_pDeviceContext->VSSetShader(m_pVertexShader, nullptr, 0);
    m_pDeviceContext->PSSetShader(m_pLightPixelShader, nullptr, 0);
    
    m_pDeviceContext->VSSetConstantBuffers(1, 1, &m_pVPBuffer);
    
    ID3D11ShaderResourceView* nullSRV = nullptr;
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(1, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(5, 1, &nullSRV);
    
    const float lightSphereRadius = 0.25f;
    
    for (int i = 0; i < 3; ++i)
    {
        XMMATRIX world =
            XMMatrixScaling(lightSphereRadius, lightSphereRadius, lightSphereRadius) *
            XMMatrixTranslation(
                m_LightPositions[i].x,
                m_LightPositions[i].y,
                m_LightPositions[i].z
            );

        XMMATRIX worldT = XMMatrixTranspose(world);
        m_pDeviceContext->UpdateSubresource(m_pModelBuffer, 0, nullptr, &worldT, 0, 0);
        m_pDeviceContext->VSSetConstantBuffers(0, 1, &m_pModelBuffer);
        
        ColorBuffer colorData = {};

        float visualIntensity = 2.0f * m_LightBrightness[i];

        colorData.color = XMFLOAT4(
            m_LightColors[i].x * visualIntensity,
            m_LightColors[i].y * visualIntensity,
            m_LightColors[i].z * visualIntensity,
            1.0f
        );

        
        m_pDeviceContext->UpdateSubresource(m_pColorBuffer, 0, nullptr, &colorData, 0, 0);
        m_pDeviceContext->PSSetConstantBuffers(0, 1, &m_pColorBuffer);
        
        m_pDeviceContext->DrawIndexed(m_indexCount, 0, 0);
    }
}

void RenderClass::SetLightBrightness(int index, float value)
{
    if (index < 0 || index >= 3) return;
    if (value < 0.0f) value = 0.0f;
    if (value > 3.0) value = 3.0;
    m_LightBrightness[index] = value;
}

float RenderClass::GetLightBrightness(int index) const
{
    if (index < 0 || index >= 3) return 0.0f;
    return m_LightBrightness[index];
}

void RenderClass::ApplyToneMapping()
{
    if (!m_pHDRSceneSRV || !m_pToneMapPS || !m_pToneMapCB) return;
    m_pDeviceContext->OMSetRenderTargets(1, &m_pRenderTargetView, nullptr);
    RECT rc;
    GetClientRect(FindWindow(m_szWindowClass, m_szTitle), &rc);
    D3D11_VIEWPORT vp = {};
    vp.Width = float(rc.right - rc.left);
    vp.Height = float(rc.bottom - rc.top);
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    m_pDeviceContext->RSSetViewports(1, &vp);
    UINT stride = sizeof(FullScreenVertex);
    UINT offset = 0;
    m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pFullScreenQuadVB, &stride, &offset);
    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
    m_pDeviceContext->IASetInputLayout(m_pFullScreenLayout);
    m_pDeviceContext->VSSetShader(m_pFullScreenVS, nullptr, 0);
    m_pDeviceContext->PSSetShader(m_pToneMapPS, nullptr, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &m_pHDRSceneSRV);
    ID3D11ShaderResourceView* bloomSRV = m_EnableBloom ? m_pBloomSRVA : nullptr;
    m_pDeviceContext->PSSetShaderResources(1, 1, &bloomSRV);
    m_pDeviceContext->PSSetSamplers(0, 1, &m_pSamplerState);
    D3D11_MAPPED_SUBRESOURCE mapped = {};
    if (SUCCEEDED(m_pDeviceContext->Map(m_pToneMapCB, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped)))
    {
        ToneMapParamsCB* cb = (ToneMapParamsCB*)mapped.pData;
        cb->Params = XMFLOAT4(
            m_AdaptedLuminance,
            m_BloomIntensity,
            m_EnableBloom ? 1.0f : 0.0f,
            0.0f
        );
        m_pDeviceContext->Unmap(m_pToneMapCB, 0);
    }
    m_pDeviceContext->PSSetConstantBuffers(0, 1, &m_pToneMapCB);
    m_pDeviceContext->Draw(4, 0);
    ID3D11ShaderResourceView* nullSRV = nullptr;
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(1, 1, &nullSRV);
}

HRESULT RenderClass::ConvolveCubemapToIrradiance(
    ID3D11ShaderResourceView* environmentCubeSRV,
    UINT irradianceSize,
    ID3D11ShaderResourceView** outIrradianceSRV)
{
    if (!environmentCubeSRV || !outIrradianceSRV)
        return E_INVALIDARG;

    *outIrradianceSRV = nullptr;

    UINT oldViewportCount = 1;
    D3D11_VIEWPORT oldViewport = {};
    m_pDeviceContext->RSGetViewports(&oldViewportCount, &oldViewport);

    ID3D11RenderTargetView* oldRTV = nullptr;
    ID3D11DepthStencilView* oldDSV = nullptr;
    m_pDeviceContext->OMGetRenderTargets(1, &oldRTV, &oldDSV);

    ID3D11RasterizerState* pOldRS = nullptr;
    m_pDeviceContext->RSGetState(&pOldRS);

    D3D11_TEXTURE2D_DESC cubeDesc = {};
    cubeDesc.Width = irradianceSize;
    cubeDesc.Height = irradianceSize;
    cubeDesc.MipLevels = 1;
    cubeDesc.ArraySize = 6;
    cubeDesc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
    cubeDesc.SampleDesc.Count = 1;
    cubeDesc.Usage = D3D11_USAGE_DEFAULT;
    cubeDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
    cubeDesc.MiscFlags = D3D11_RESOURCE_MISC_TEXTURECUBE;

    ID3D11Texture2D* irradianceTex = nullptr;
    HRESULT hr = m_pDevice->CreateTexture2D(&cubeDesc, nullptr, &irradianceTex);
    if (FAILED(hr))
        return hr;

    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
    srvDesc.Format = cubeDesc.Format;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURECUBE;
    srvDesc.TextureCube.MostDetailedMip = 0;
    srvDesc.TextureCube.MipLevels = 1;

    ID3D11ShaderResourceView* irradianceSRV = nullptr;
    hr = m_pDevice->CreateShaderResourceView(irradianceTex, &srvDesc, &irradianceSRV);
    if (FAILED(hr))
    {
        irradianceTex->Release();
        return hr;
    }

    ID3D11RenderTargetView* faceRTV[6] = {};
    for (UINT i = 0; i < 6; ++i)
    {
        D3D11_RENDER_TARGET_VIEW_DESC rtvDesc = {};
        rtvDesc.Format = cubeDesc.Format;
        rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DARRAY;
        rtvDesc.Texture2DArray.MipSlice = 0;
        rtvDesc.Texture2DArray.FirstArraySlice = i;
        rtvDesc.Texture2DArray.ArraySize = 1;

        hr = m_pDevice->CreateRenderTargetView(irradianceTex, &rtvDesc, &faceRTV[i]);
        if (FAILED(hr))
        {
            for (UINT k = 0; k < i; ++k)
                if (faceRTV[k]) faceRTV[k]->Release();
            irradianceSRV->Release();
            irradianceTex->Release();
            return hr;
        }
    }

    D3D11_RASTERIZER_DESC rsDesc = {};
    rsDesc.FillMode = D3D11_FILL_SOLID;
    rsDesc.CullMode = D3D11_CULL_FRONT;
    rsDesc.FrontCounterClockwise = FALSE;
    rsDesc.DepthClipEnable = TRUE;

    ID3D11RasterizerState* pCubeRS = nullptr;
    hr = m_pDevice->CreateRasterizerState(&rsDesc, &pCubeRS);
    if (FAILED(hr))
    {
        for (UINT i = 0; i < 6; ++i)
            if (faceRTV[i]) faceRTV[i]->Release();
        irradianceSRV->Release();
        irradianceTex->Release();
        if (pOldRS) pOldRS->Release();
        return hr;
    }

    m_pDeviceContext->RSSetState(pCubeRS);

    D3D11_VIEWPORT vp = {};
    vp.TopLeftX = 0.0f;
    vp.TopLeftY = 0.0f;
    vp.Width = static_cast<float>(irradianceSize);
    vp.Height = static_cast<float>(irradianceSize);
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    m_pDeviceContext->RSSetViewports(1, &vp);

    UINT stride = sizeof(CubeVertex);
    UINT offset = 0;
    m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pVertexBuffer, &stride, &offset);
    m_pDeviceContext->IASetIndexBuffer(m_pIndexBuffer, DXGI_FORMAT_R16_UINT, 0);
    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    m_pDeviceContext->IASetInputLayout(m_pSkyLayout);

    m_pDeviceContext->VSSetShader(m_pSkyVertexShader, nullptr, 0);
    m_pDeviceContext->PSSetShader(m_pIrradianceConvolutionPS, nullptr, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &environmentCubeSRV);
    m_pDeviceContext->PSSetSamplers(0, 1, &m_pSamplerState);
    m_pDeviceContext->VSSetConstantBuffers(0, 1, &m_pModelBuffer);
    m_pDeviceContext->VSSetConstantBuffers(1, 1, &m_pVPBuffer);

    XMMATRIX proj = XMMatrixPerspectiveFovLH(XM_PIDIV2, 1.0f, 0.1f, 10.0f);
    XMVECTOR eye = XMVectorZero();

    const XMVECTOR targets[6] =
    {
        XMVectorSet(1,  0,  0, 0),
        XMVectorSet(-1,  0,  0, 0),
        XMVectorSet(0,  1,  0, 0),
        XMVectorSet(0, -1,  0, 0),
        XMVectorSet(0,  0,  1, 0),
        XMVectorSet(0,  0, -1, 0)
    };

    const XMVECTOR ups[6] =
    {
        XMVectorSet(0, 1, 0, 0),
        XMVectorSet(0, 1, 0, 0),
        XMVectorSet(0, 0,-1, 0),
        XMVectorSet(0, 0, 1, 0),
        XMVectorSet(0, 1, 0, 0),
        XMVectorSet(0, 1, 0, 0)
    };

    XMMATRIX model = XMMatrixIdentity();
    XMMATRIX modelT = XMMatrixTranspose(model);
    m_pDeviceContext->UpdateSubresource(m_pModelBuffer, 0, nullptr, &modelT, 0, 0);

    for (UINT face = 0; face < 6; ++face)
    {
        float clearColor[4] = { 0, 0, 0, 1 };
        m_pDeviceContext->OMSetRenderTargets(1, &faceRTV[face], nullptr);
        m_pDeviceContext->ClearRenderTargetView(faceRTV[face], clearColor);

        CameraBuffer cb = {};
        cb.vp = XMMatrixTranspose(XMMatrixLookToLH(eye, targets[face], ups[face]) * proj);
        cb.cameraPos = XMFLOAT3(0, 0, 0);

        D3D11_MAPPED_SUBRESOURCE mapped = {};
        hr = m_pDeviceContext->Map(m_pVPBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
        if (FAILED(hr))
            break;

        memcpy(mapped.pData, &cb, sizeof(cb));
        m_pDeviceContext->Unmap(m_pVPBuffer, 0);

        m_pDeviceContext->DrawIndexed(m_indexCount, 0, 0);
    }

    ID3D11ShaderResourceView* nullSRV = nullptr;
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);

    m_pDeviceContext->RSSetState(pOldRS);
    if (pOldRS) pOldRS->Release();
    if (pCubeRS) pCubeRS->Release();

    m_pDeviceContext->OMSetRenderTargets(1, &oldRTV, oldDSV);
    m_pDeviceContext->RSSetViewports(1, &oldViewport);

    if (oldRTV) oldRTV->Release();
    if (oldDSV) oldDSV->Release();

    for (UINT i = 0; i < 6; ++i)
        if (faceRTV[i]) faceRTV[i]->Release();

    irradianceTex->Release();

    if (FAILED(hr))
    {
        irradianceSRV->Release();
        return hr;
    }

    *outIrradianceSRV = irradianceSRV;
    return S_OK;
 }

 HRESULT RenderClass::GenerateBRDFLUT(
     UINT lutWidth,
     UINT lutHeight,
     ID3D11ShaderResourceView** outBRDFLUTSRV)
 {
     if (!outBRDFLUTSRV)
         return E_INVALIDARG;
     *outBRDFLUTSRV = nullptr;
     ID3D11RenderTargetView* oldRTV = nullptr;
     ID3D11DepthStencilView* oldDSV = nullptr;
     m_pDeviceContext->OMGetRenderTargets(1, &oldRTV, &oldDSV);
     UINT oldViewportCount = 1;
     D3D11_VIEWPORT oldViewport = {};
     m_pDeviceContext->RSGetViewports(&oldViewportCount, &oldViewport);
     ID3D11InputLayout* oldLayout = nullptr;
     ID3D11VertexShader* oldVS = nullptr;
     ID3D11PixelShader * oldPS = nullptr;
     m_pDeviceContext->IAGetInputLayout(&oldLayout);
     m_pDeviceContext->VSGetShader(&oldVS, nullptr, nullptr);
     m_pDeviceContext->PSGetShader(&oldPS, nullptr, nullptr);
     D3D11_TEXTURE2D_DESC texDesc = {};
     texDesc.Width = lutWidth;
     texDesc.Height = lutHeight;
     texDesc.MipLevels = 1;
     texDesc.ArraySize = 1;
     texDesc.Format = DXGI_FORMAT_R16G16_FLOAT;
     texDesc.SampleDesc.Count = 1;
     texDesc.Usage = D3D11_USAGE_DEFAULT;
     texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
     ID3D11Texture2D* lutTex = nullptr;
     HRESULT hr = m_pDevice->CreateTexture2D(&texDesc, nullptr, &lutTex);
     if (FAILED(hr))
         return hr;
     ID3D11RenderTargetView* lutRTV = nullptr;
     hr = m_pDevice->CreateRenderTargetView(lutTex, nullptr, &lutRTV);
     if (FAILED(hr))
     {
         lutTex->Release();
         return hr;
     }
     ID3D11ShaderResourceView* lutSRV = nullptr;
     hr = m_pDevice->CreateShaderResourceView(lutTex, nullptr, &lutSRV);
     if (FAILED(hr))
     {
         lutRTV->Release();
         lutTex->Release();
         return hr;
     }
     float clearColor[4] = { 0, 0, 0, 0 };
     m_pDeviceContext->OMSetRenderTargets(1, &lutRTV, nullptr);
     m_pDeviceContext->ClearRenderTargetView(lutRTV, clearColor);
     D3D11_VIEWPORT vp = {};
     vp.Width = (FLOAT)lutWidth;
     vp.Height = (FLOAT)lutHeight;
     vp.MinDepth = 0.0f;
     vp.MaxDepth = 1.0f;
     vp.TopLeftX = 0;
     vp.TopLeftY = 0;
     m_pDeviceContext->RSSetViewports(1, &vp);
     UINT stride = sizeof(FullScreenVertex);
     UINT offset = 0;
     m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pFullScreenQuadVB, &stride, &offset);
     m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
     m_pDeviceContext->IASetInputLayout(m_pFullScreenLayout);
     m_pDeviceContext->VSSetShader(m_pFullScreenVS, nullptr, 0);
     m_pDeviceContext->PSSetShader(m_pBRDFIntegrationPS, nullptr, 0);
     m_pDeviceContext->Draw(4, 0);
     m_pDeviceContext->OMSetRenderTargets(1, &oldRTV, oldDSV);
     m_pDeviceContext->RSSetViewports(1, &oldViewport);
     m_pDeviceContext->IASetInputLayout(oldLayout);
     m_pDeviceContext->VSSetShader(oldVS, nullptr, 0);
     m_pDeviceContext->PSSetShader(oldPS, nullptr, 0);
     if (oldLayout) oldLayout->Release();
     if (oldVS) oldVS->Release();
     if (oldPS) oldPS->Release();
     if (oldRTV) oldRTV->Release();
     if (oldDSV) oldDSV->Release();
     lutRTV->Release();
     lutTex->Release();
     *outBRDFLUTSRV = lutSRV;
     return S_OK;
 }

 HRESULT RenderClass::PrefilterCubemapSpecular(
     ID3D11ShaderResourceView* environmentCubeSRV,
     UINT prefilterSize,
     UINT mipLevels,
     ID3D11ShaderResourceView** outPrefilterSRV) 
 {
     if (!environmentCubeSRV || !outPrefilterSRV)
         return E_INVALIDARG;

     *outPrefilterSRV = nullptr;

     UINT oldViewportCount = 1;
     D3D11_VIEWPORT oldViewport = {};
     m_pDeviceContext->RSGetViewports(&oldViewportCount, &oldViewport);

     ID3D11RenderTargetView* oldRTV = nullptr;
     ID3D11DepthStencilView* oldDSV = nullptr;
     m_pDeviceContext->OMGetRenderTargets(1, &oldRTV, &oldDSV);

     ID3D11RasterizerState* pOldRS = nullptr;
     m_pDeviceContext->RSGetState(&pOldRS);
     D3D11_TEXTURE2D_DESC cubeDesc = {};
     cubeDesc.Width = prefilterSize;
     cubeDesc.Height = prefilterSize;
     cubeDesc.MipLevels = mipLevels;
     cubeDesc.ArraySize = 6;
     cubeDesc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
     cubeDesc.SampleDesc.Count = 1;
     cubeDesc.Usage = D3D11_USAGE_DEFAULT;
     cubeDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET;
     cubeDesc.MiscFlags = D3D11_RESOURCE_MISC_TEXTURECUBE;

     ID3D11Texture2D* prefilterTex = nullptr;
     HRESULT hr = m_pDevice->CreateTexture2D(&cubeDesc, nullptr, &prefilterTex);
     if (FAILED(hr))
         return hr;
     D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
     srvDesc.Format = cubeDesc.Format;
     srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURECUBE;
     srvDesc.TextureCube.MostDetailedMip = 0;
     srvDesc.TextureCube.MipLevels = mipLevels;

     ID3D11ShaderResourceView* prefilterSRV = nullptr;
     hr = m_pDevice->CreateShaderResourceView(prefilterTex, &srvDesc, &prefilterSRV);
     if (FAILED(hr))
     {
         prefilterTex->Release();
         return hr;
     }
     std::vector<ID3D11RenderTargetView*> rtvs;
     rtvs.resize(mipLevels * 6, nullptr);

     for (UINT mip = 0; mip < mipLevels; ++mip)
     {
         for (UINT face = 0; face < 6; ++face)
         {
             D3D11_RENDER_TARGET_VIEW_DESC rtvDesc = {};
             rtvDesc.Format = cubeDesc.Format;
             rtvDesc.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2DARRAY;
             rtvDesc.Texture2DArray.MipSlice = mip;
             rtvDesc.Texture2DArray.FirstArraySlice = face;
             rtvDesc.Texture2DArray.ArraySize = 1;

             hr = m_pDevice->CreateRenderTargetView(
                 prefilterTex,
                 &rtvDesc,
                 &rtvs[mip * 6 + face]
             );

             if (FAILED(hr))
             {
                 for (auto* rtv : rtvs)
                     if (rtv) rtv->Release();
                 prefilterSRV->Release();
                 prefilterTex->Release();
                 if (pOldRS) pOldRS->Release();
                 return hr;
             }
         }
     }
     D3D11_RASTERIZER_DESC rsDesc = {};
     rsDesc.FillMode = D3D11_FILL_SOLID;
     rsDesc.CullMode = D3D11_CULL_FRONT;
     rsDesc.FrontCounterClockwise = FALSE;
     rsDesc.DepthClipEnable = TRUE;

     ID3D11RasterizerState* pCubeRS = nullptr;
     hr = m_pDevice->CreateRasterizerState(&rsDesc, &pCubeRS);
     if (FAILED(hr))
     {
         for (auto* rtv : rtvs)
             if (rtv) rtv->Release();
         prefilterSRV->Release();
         prefilterTex->Release();
         if (pOldRS) pOldRS->Release();
         return hr;
     }

     m_pDeviceContext->RSSetState(pCubeRS);
     UINT stride = sizeof(CubeVertex);
     UINT offset = 0;
     m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pVertexBuffer, &stride, &offset);
     m_pDeviceContext->IASetIndexBuffer(m_pIndexBuffer, DXGI_FORMAT_R16_UINT, 0);
     m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
     m_pDeviceContext->IASetInputLayout(m_pSkyLayout);

     m_pDeviceContext->VSSetShader(m_pSkyVertexShader, nullptr, 0);
     m_pDeviceContext->PSSetShader(m_pSpecularPrefilterPS, nullptr, 0);
     m_pDeviceContext->PSSetShaderResources(0, 1, &environmentCubeSRV);
     m_pDeviceContext->PSSetSamplers(0, 1, &m_pSamplerState);

     m_pDeviceContext->VSSetConstantBuffers(0, 1, &m_pModelBuffer);
     m_pDeviceContext->VSSetConstantBuffers(1, 1, &m_pVPBuffer);
     m_pDeviceContext->PSSetConstantBuffers(4, 1, &m_pSpecularPrefilterCB);
     XMMATRIX proj = XMMatrixPerspectiveFovLH(XM_PIDIV2, 1.0f, 0.1f, 10.0f);
     XMVECTOR eye = XMVectorZero();

     const XMVECTOR targets[6] =
     {
         XMVectorSet(1,  0,  0, 0),
         XMVectorSet(-1, 0,  0, 0),
         XMVectorSet(0,  1,  0, 0),
         XMVectorSet(0, -1,  0, 0),
         XMVectorSet(0,  0,  1, 0),
         XMVectorSet(0,  0, -1, 0)
     };

     const XMVECTOR ups[6] =
     {
         XMVectorSet(0, 1, 0, 0),
         XMVectorSet(0, 1, 0, 0),
         XMVectorSet(0, 0,-1, 0),
         XMVectorSet(0, 0, 1, 0),
         XMVectorSet(0, 1, 0, 0),
         XMVectorSet(0, 1, 0, 0)
     };

     XMMATRIX model = XMMatrixIdentity();
     XMMATRIX modelT = XMMatrixTranspose(model);
     m_pDeviceContext->UpdateSubresource(m_pModelBuffer, 0, nullptr, &modelT, 0, 0);
     for (UINT mip = 0; mip < mipLevels; ++mip)
     {
         UINT mipWidth = std::max(1u, prefilterSize >> mip);
         UINT mipHeight = std::max(1u, prefilterSize >> mip);

         D3D11_VIEWPORT vp = {};
         vp.TopLeftX = 0.0f;
         vp.TopLeftY = 0.0f;
         vp.Width = static_cast<float>(mipWidth);
         vp.Height = static_cast<float>(mipHeight);
         vp.MinDepth = 0.0f;
         vp.MaxDepth = 1.0f;
         m_pDeviceContext->RSSetViewports(1, &vp);

         float roughness = (mipLevels > 1)
             ? (float)mip / (float)(mipLevels - 1)
             : 0.0f;

         SpecularPrefilterCB prefilterCB = {};
         prefilterCB.Params = XMFLOAT4(roughness, (float)mipLevels, 0.0f, 0.0f);
         m_pDeviceContext->UpdateSubresource(
             m_pSpecularPrefilterCB,
             0,
             nullptr,
             &prefilterCB,
             0,
             0
         );

         for (UINT face = 0; face < 6; ++face)
         {
             float clearColor[4] = { 0, 0, 0, 1 };
             ID3D11RenderTargetView* rtv = rtvs[mip * 6 + face];

             m_pDeviceContext->OMSetRenderTargets(1, &rtv, nullptr);
             m_pDeviceContext->ClearRenderTargetView(rtv, clearColor);

             CameraBuffer cb = {};
             cb.vp = XMMatrixTranspose(XMMatrixLookToLH(eye, targets[face], ups[face]) * proj);
             cb.cameraPos = XMFLOAT3(0, 0, 0);

             D3D11_MAPPED_SUBRESOURCE mapped = {};
             hr = m_pDeviceContext->Map(m_pVPBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped);
             if (FAILED(hr))
                 break;

             memcpy(mapped.pData, &cb, sizeof(cb));
             m_pDeviceContext->Unmap(m_pVPBuffer, 0);

             m_pDeviceContext->DrawIndexed(m_indexCount, 0, 0);
         }

         if (FAILED(hr))
             break;
     }
     ID3D11ShaderResourceView* nullSRV = nullptr;
     m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);

     m_pDeviceContext->RSSetState(pOldRS);
     if (pOldRS) pOldRS->Release();
     if (pCubeRS) pCubeRS->Release();

     m_pDeviceContext->OMSetRenderTargets(1, &oldRTV, oldDSV);
     m_pDeviceContext->RSSetViewports(1, &oldViewport);

     if (oldRTV) oldRTV->Release();
     if (oldDSV) oldDSV->Release();

     for (auto* rtv : rtvs)
         if (rtv) rtv->Release();

     prefilterTex->Release();

     if (FAILED(hr))
     {
         prefilterSRV->Release();
         return hr;
     }

     *outPrefilterSRV = prefilterSRV;
     return S_OK;
}

// gltf

bool RenderClass::LoadModelResource(const std::wstring& path, int& outResourceIndex)
{
    outResourceIndex = -1;

    GltfModelResource resource = {};
    resource.FilePath = path;

    if (!LoadGltfScene(path, resource.Scene))
        return false;

    HRESULT hr = CreateGltfGpuResources(resource);
    if (FAILED(hr))
    {
        ReleaseGltfGpuResources(resource);
        return false;
    }

    m_ModelResources.push_back(std::move(resource));
    outResourceIndex = (int)m_ModelResources.size() - 1;
    return true;
}

void RenderClass::LoadSceneModels()
{
    m_ModelResources.clear();
    m_SceneModelInstances.clear();

    const std::vector<SceneModelDesc> descs = GetSceneModelDescs();

    for (const auto& desc : descs)
    {
        int resourceIndex = -1;
        if (!LoadModelResource(desc.FilePath, resourceIndex))
        {
            std::wstring msg = L"Failed to load model: " + desc.FilePath + L"\n";
            OutputDebugStringW(msg.c_str());
        }
    }

    BuildSceneLayout();
    PrecomputeSceneModelTransforms();
    CollectShadowCasters();
}

void RenderClass::ReleaseGltfGpuResources(GltfModelResource& model)
{
    for (auto& mesh : model.GpuMeshes)
    {
        for (auto& prim : mesh.Primitives)
        {
            if (prim.VertexBuffer)
            {
                prim.VertexBuffer->Release();
                prim.VertexBuffer = nullptr;
            }

            if (prim.IndexBuffer)
            {
                prim.IndexBuffer->Release();
                prim.IndexBuffer = nullptr;
            }
        }
    }

    model.GpuMeshes.clear();

    for (auto* srv : model.TextureSRVs)
    {
        if (srv)
            srv->Release();
    }

    model.TextureSRVs.clear();
}

void RenderClass::ReleaseAllGltfModelResources()
{
    for (auto& model : m_ModelResources)
    {
        ReleaseGltfGpuResources(model);
    }

    m_ModelResources.clear();
    m_SceneModelInstances.clear();
}

HRESULT RenderClass::CreateTextureSRVFromFile(const std::wstring& path, ID3D11ShaderResourceView** outSRV)
{
    if (!outSRV)
        return E_INVALIDARG;
    *outSRV = nullptr;
    int width = 0;
    int height = 0;
    int channels = 0;
    std::string narrow(path.begin(), path.end());
    unsigned char* pixels = stbi_load(narrow.c_str(), &width, &height, &channels, 4);
    if (!pixels)
        return E_FAIL;

    D3D11_TEXTURE2D_DESC desc = {};
    desc.Width = (UINT)width;
    desc.Height = (UINT)height;
    desc.MipLevels = 1;
    desc.ArraySize = 1;
    desc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    desc.SampleDesc.Count = 1;
    desc.Usage = D3D11_USAGE_DEFAULT;
    desc.BindFlags = D3D11_BIND_SHADER_RESOURCE;

    D3D11_SUBRESOURCE_DATA initData = {};
    initData.pSysMem = pixels;
    initData.SysMemPitch = width * 4;
    ID3D11Texture2D* texture = nullptr;
    HRESULT hr = m_pDevice->CreateTexture2D(&desc, &initData, &texture);
    stbi_image_free(pixels);

    if (FAILED(hr))
        return hr;

    hr = m_pDevice->CreateShaderResourceView(texture, nullptr, outSRV);
    texture->Release();
    return hr;
}

HRESULT RenderClass::CreateGltfGpuResources(GltfModelResource& model)
{
    ReleaseGltfGpuResources(model);

    HRESULT hr = S_OK;

    model.GpuMeshes.resize(model.Scene.Meshes.size());

    for (size_t meshIndex = 0; meshIndex < model.Scene.Meshes.size(); ++meshIndex)
    {
        const GltfMeshData& srcMesh = model.Scene.Meshes[meshIndex];
        GltfGpuMesh& dstMesh = model.GpuMeshes[meshIndex];
        dstMesh.Primitives.resize(srcMesh.Primitives.size());

        for (size_t primIndex = 0; primIndex < srcMesh.Primitives.size(); ++primIndex)
        {
            const GltfPrimitiveData& srcPrim = srcMesh.Primitives[primIndex];
            GltfGpuPrimitive& dstPrim = dstMesh.Primitives[primIndex];

            dstPrim.MaterialIndex = srcPrim.MaterialIndex;
            dstPrim.IndexCount = (UINT)srcPrim.Indices.size();
            dstPrim.IndexFormat = DXGI_FORMAT_R32_UINT;

            if (srcPrim.Vertices.empty() || srcPrim.Indices.empty())
                continue;

            D3D11_BUFFER_DESC vbDesc = {};
            vbDesc.Usage = D3D11_USAGE_DEFAULT;
            vbDesc.ByteWidth = (UINT)(sizeof(GltfVertex) * srcPrim.Vertices.size());
            vbDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;

            D3D11_SUBRESOURCE_DATA vbData = {};
            vbData.pSysMem = srcPrim.Vertices.data();

            hr = m_pDevice->CreateBuffer(&vbDesc, &vbData, &dstPrim.VertexBuffer);
            if (FAILED(hr))
                return hr;

            D3D11_BUFFER_DESC ibDesc = {};
            ibDesc.Usage = D3D11_USAGE_DEFAULT;
            ibDesc.ByteWidth = (UINT)(sizeof(uint32_t) * srcPrim.Indices.size());
            ibDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;

            D3D11_SUBRESOURCE_DATA ibData = {};
            ibData.pSysMem = srcPrim.Indices.data();

            hr = m_pDevice->CreateBuffer(&ibDesc, &ibData, &dstPrim.IndexBuffer);
            if (FAILED(hr))
                return hr;
        }
    }

    model.TextureSRVs.resize(model.Scene.Textures.size(), nullptr);

    for (size_t i = 0; i < model.Scene.Textures.size(); ++i)
    {
        const auto& tex = model.Scene.Textures[i];
        if (!tex.Uri.empty())
        {
            CreateTextureSRVFromFile(tex.Uri, &model.TextureSRVs[i]);
        }
    }

    return S_OK;
}

void RenderClass::DrawGltfPrimitive(
    const GltfModelResource& model,
    const GltfGpuPrimitive& primitive,
    const XMMATRIX& world,
    const XMMATRIX& viewProj)
{
    if (!primitive.VertexBuffer || !primitive.IndexBuffer || primitive.IndexCount == 0)
        return;

    XMMATRIX worldT = XMMatrixTranspose(world);
    m_pDeviceContext->UpdateSubresource(m_pModelBuffer, 0, nullptr, &worldT, 0, 0);
    m_pDeviceContext->VSSetConstantBuffers(0, 1, &m_pModelBuffer);

    MaterialParamsCB materialParams = {};
    materialParams.Surface = XMFLOAT4(
        m_MaterialMetalness,
        m_MaterialRoughness,
        m_MaterialAO,
        m_NormalStrength
    );
    materialParams.Albedo = XMFLOAT4(1, 1, 1, 0);
    materialParams.DebugView = XMFLOAT4(
        (float)m_DebugViewMode,
        m_EnableSpecularIBL ? 1.0f : 0.0f,
        m_DiffuseIBLIntensity,
        m_SpecularIBLIntensity
    );

    ID3D11ShaderResourceView* albedoSRV = nullptr;
    ID3D11ShaderResourceView* normalSRV = nullptr;
    ID3D11ShaderResourceView* emissiveSRV = nullptr;

    if (primitive.MaterialIndex >= 0 &&
        primitive.MaterialIndex < (int)model.Scene.Materials.size())
    {
        const GltfMaterial& mat = model.Scene.Materials[primitive.MaterialIndex];

        materialParams.Emissive = XMFLOAT4(0, 0, 0, 0);
        materialParams.Surface.x = mat.MetallicFactor;
        materialParams.Surface.y = mat.RoughnessFactor;
        materialParams.Surface.z = 1.0f;
        materialParams.Surface.w = 1.0f;

        materialParams.Albedo = XMFLOAT4(
            mat.BaseColorFactor.x,
            mat.BaseColorFactor.y,
            mat.BaseColorFactor.z,
            (mat.BaseColorTexture >= 0) ? 1.0f : 0.0f
        );

        materialParams.Emissive = XMFLOAT4(
            mat.EmissiveFactor.x,
            mat.EmissiveFactor.y,
            mat.EmissiveFactor.z,
            (mat.EmissiveTexture >= 0) ? 1.0f : 0.0f
        );

        if (mat.BaseColorTexture >= 0 &&
            mat.BaseColorTexture < (int)model.TextureSRVs.size())
        {
            albedoSRV = model.TextureSRVs[mat.BaseColorTexture];
        }

        if (mat.NormalTexture >= 0 &&
            mat.NormalTexture < (int)model.TextureSRVs.size())
        {
            normalSRV = model.TextureSRVs[mat.NormalTexture];
        }

        if (mat.EmissiveTexture >= 0 &&
            mat.EmissiveTexture < (int)model.TextureSRVs.size())
        {
            emissiveSRV = model.TextureSRVs[mat.EmissiveTexture];
        }
    }

    m_pDeviceContext->UpdateSubresource(m_pMaterialBuffer, 0, nullptr, &materialParams, 0, 0);
    m_pDeviceContext->PSSetConstantBuffers(3, 1, &m_pMaterialBuffer);
    
    UINT stride = sizeof(GltfVertex);
    UINT offset = 0;
    
    m_pDeviceContext->IASetVertexBuffers(0, 1, &primitive.VertexBuffer, &stride, &offset);
    m_pDeviceContext->IASetIndexBuffer(primitive.IndexBuffer, primitive.IndexFormat, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &albedoSRV);
    m_pDeviceContext->PSSetShaderResources(1, 1, &normalSRV);
    m_pDeviceContext->PSSetShaderResources(5, 1, &emissiveSRV);

    m_pDeviceContext->VSSetConstantBuffers(4, 1, &m_pShadowLightBuffer);
    m_pDeviceContext->PSSetConstantBuffers(4, 1, &m_pShadowParamsBuffer);
    m_pDeviceContext->PSSetShaderResources(6, 1, &m_pShadowMapSRV);
    m_pDeviceContext->PSSetSamplers(1, 1, &m_pShadowSampler);
    m_pDeviceContext->PSSetSamplers(2, 1, &m_pShadowSampler);

    m_pDeviceContext->DrawIndexed(primitive.IndexCount, 0, 0);
}

void RenderClass::RenderGltfNode(
    const GltfModelResource& model,
    int nodeIndex,
    const XMMATRIX& viewProj,
    const XMMATRIX& instanceWorld)
{
    if (nodeIndex < 0 || nodeIndex >= (int)model.Scene.Nodes.size())
        return;

    const GltfNodeData& node = model.Scene.Nodes[nodeIndex];
    XMMATRIX nodeWorld = XMLoadFloat4x4(&node.WorldMatrix);

    XMMATRIX finalWorld = nodeWorld * instanceWorld;

    if (node.MeshIndex >= 0 && node.MeshIndex < (int)model.GpuMeshes.size())
    {
        const GltfGpuMesh& mesh = model.GpuMeshes[node.MeshIndex];
        for (const auto& prim : mesh.Primitives)
        {
            DrawGltfPrimitive(model, prim, finalWorld, viewProj);
        }
    }

    for (int child : node.Children)
    {
        RenderGltfNode(model, child, viewProj, instanceWorld);
    }
}

void RenderClass::RenderAllSceneModels(const XMMATRIX& viewProj)
{
    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    m_pDeviceContext->IASetInputLayout(m_pLayout);
    m_pDeviceContext->VSSetShader(m_pVertexShader, nullptr, 0);
    m_pDeviceContext->PSSetShader(m_pPixelShader, nullptr, 0);
    m_pDeviceContext->PSSetSamplers(0, 1, &m_pSamplerState);
    m_pDeviceContext->PSSetShaderResources(2, 1, &m_pIrradianceSRV);
    m_pDeviceContext->PSSetShaderResources(3, 1, &m_pPrefilteredEnvSRV);
    m_pDeviceContext->PSSetShaderResources(4, 1, &m_pBRDFLUTSRV);
    m_pDeviceContext->RSSetState(m_pGltfRasterState);

    for (const SceneModelInstance& instance : m_SceneModelInstances)
    {
        RenderModelInstance(instance, viewProj);
    }

    m_pDeviceContext->RSSetState(nullptr);

    ID3D11ShaderResourceView* nullSRV = nullptr;
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(1, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(2, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(3, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(4, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(5, 1, &nullSRV);
    m_pDeviceContext->PSSetShaderResources(6, 1, &nullSRV);
}

void RenderClass::RenderModelInstance(const SceneModelInstance& instance, const XMMATRIX& viewProj)
{
    if (instance.ModelResourceIndex < 0 ||
        instance.ModelResourceIndex >= (int)m_ModelResources.size())
    {
        return;
    }

    const GltfModelResource& model = m_ModelResources[instance.ModelResourceIndex];

    for (int rootNode : model.Scene.RootNodes)
    {
        RenderGltfNode(model, rootNode, viewProj, instance.PrecomputedWorld);
    }
}

// bloom

HRESULT RenderClass::CreateBloomResources(UINT width, UINT height)
{
    ReleaseBloomResources();
    width = std::max(1u, width / 2);
    height = std::max(1u, height / 2);
    D3D11_TEXTURE2D_DESC texDesc = {};
    texDesc.Width = width;
    texDesc.Height = height;
    texDesc.MipLevels = 1;
    texDesc.ArraySize = 1;
    texDesc.Format = DXGI_FORMAT_R16G16B16A16_FLOAT;
    texDesc.SampleDesc.Count = 1;
    texDesc.Usage = D3D11_USAGE_DEFAULT;
    texDesc.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
    
    HRESULT result = m_pDevice->CreateTexture2D(&texDesc, nullptr, &m_pBloomTextureA);
    if (FAILED(result)) 
        return result;

    result = m_pDevice->CreateRenderTargetView(m_pBloomTextureA, nullptr, &m_pBloomRTVA);
    if (FAILED(result)) 
        return result;

    result = m_pDevice->CreateShaderResourceView(m_pBloomTextureA, nullptr, &m_pBloomSRVA);
    if (FAILED(result)) 
        return result;

    result = m_pDevice->CreateTexture2D(&texDesc, nullptr, &m_pBloomTextureB);
    if (FAILED(result)) 
        return result;

    result = m_pDevice->CreateRenderTargetView(m_pBloomTextureB, nullptr, &m_pBloomRTVB);
    if (FAILED(result)) 
        return result;

    result = m_pDevice->CreateShaderResourceView(m_pBloomTextureB, nullptr, &m_pBloomSRVB);
    if (FAILED(result)) 
        return result;

    return S_OK;
}

void RenderClass::ReleaseBloomResources()
{
    if (m_pBloomSRVA) 
    { 
        m_pBloomSRVA->Release(); 
        m_pBloomSRVA = nullptr; 
    }

    if (m_pBloomRTVA) 
    { 
        m_pBloomRTVA->Release(); 
        m_pBloomRTVA = nullptr; 
    }
    if (m_pBloomTextureA) 
    { 
        m_pBloomTextureA->Release(); 
        m_pBloomTextureA = nullptr; 
    }

    if (m_pBloomSRVB) 
    { 
        m_pBloomSRVB->Release(); 
        m_pBloomSRVB = nullptr; 
    }

    if (m_pBloomRTVB) 
    { 
        m_pBloomRTVB->Release(); 
        m_pBloomRTVB = nullptr; 
    }

    if (m_pBloomTextureB) 
    { 
        m_pBloomTextureB->Release(); 
        m_pBloomTextureB = nullptr; 
    }
}

void RenderClass::ApplyBloom()
{
    if (!m_EnableBloom || !m_pHDRSceneSRV || !m_pBloomRTVA || !m_pBloomRTVB)
        return;
    RECT rc;
    GetClientRect(FindWindow(m_szWindowClass, m_szTitle), &rc);
    float bloomWidth = std::max(1.0f, (float)(rc.right - rc.left) / 2);
    float bloomHeight = std::max(1.0f, (float)(rc.bottom - rc.top) / 2);
    D3D11_VIEWPORT vp = {};
    vp.TopLeftX = 0.0f;
    vp.TopLeftY = 0.0f;
    vp.Width = bloomWidth;
    vp.Height = bloomHeight;
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    m_pDeviceContext->RSSetViewports(1, &vp);
    UINT stride = sizeof(FullScreenVertex);
    UINT offset = 0;
    m_pDeviceContext->IASetInputLayout(m_pFullScreenLayout);
    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
    m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pFullScreenQuadVB, &stride, &offset);
    m_pDeviceContext->VSSetShader(m_pFullScreenVS, nullptr, 0);
    m_pDeviceContext->PSSetSamplers(0, 1, &m_pSamplerState);
    D3D11_MAPPED_SUBRESOURCE mapped = {};
    if (SUCCEEDED(m_pDeviceContext->Map(m_pBloomCB, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped)))
    {
        BloomParamsCB* cb = (BloomParamsCB*)mapped.pData;
        cb->Params0 = XMFLOAT4(
            m_BloomThreshold,
            m_BloomIntensity,
            (1.0f / bloomWidth) * m_BloomBlurScale,
            (1.0f / bloomHeight) * m_BloomBlurScale
        );
        cb->Params1 = XMFLOAT4(1, 0, 1, 0);
        m_pDeviceContext->Unmap(m_pBloomCB, 0);
    }
    m_pDeviceContext->PSSetConstantBuffers(0, 1, &m_pBloomCB);
    float clear[4] = { 0,0,0,0 };

    m_pDeviceContext->OMSetRenderTargets(1, &m_pBloomRTVA, nullptr);
    m_pDeviceContext->ClearRenderTargetView(m_pBloomRTVA, clear);
    m_pDeviceContext->PSSetShader(m_pBloomExtractPS, nullptr, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &m_pHDRSceneSRV);
    m_pDeviceContext->Draw(4, 0);
    ID3D11ShaderResourceView* nullSRV = nullptr;
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);

    if (SUCCEEDED(m_pDeviceContext->Map(m_pBloomCB, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped)))
    {
        BloomParamsCB* cb = (BloomParamsCB*)mapped.pData;
        cb->Params0 = XMFLOAT4(
            m_BloomThreshold,
            m_BloomIntensity,
            (1.0f / bloomWidth) * m_BloomBlurScale,
            (1.0f / bloomHeight) * m_BloomBlurScale
        );
        cb->Params1 = XMFLOAT4(1, 0, 1, 0);
        m_pDeviceContext->Unmap(m_pBloomCB, 0);
    }
    m_pDeviceContext->OMSetRenderTargets(1, &m_pBloomRTVB, nullptr);
    m_pDeviceContext->ClearRenderTargetView(m_pBloomRTVB, clear);
    m_pDeviceContext->PSSetShader(m_pBloomBlurPS, nullptr, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &m_pBloomSRVA);
    m_pDeviceContext->Draw(4, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);

    if (SUCCEEDED(m_pDeviceContext->Map(m_pBloomCB, 0, D3D11_MAP_WRITE_DISCARD, 0, &mapped)))
    {
        BloomParamsCB* cb = (BloomParamsCB*)mapped.pData;
        cb->Params0 = XMFLOAT4(
            m_BloomThreshold,
            m_BloomIntensity,
            (1.0f / bloomWidth) * m_BloomBlurScale,
            (1.0f / bloomHeight) * m_BloomBlurScale
        );
        cb->Params1 = XMFLOAT4(0, 1, 1, 0);
        m_pDeviceContext->Unmap(m_pBloomCB, 0);
    }
    m_pDeviceContext->OMSetRenderTargets(1, &m_pBloomRTVA, nullptr);
    m_pDeviceContext->ClearRenderTargetView(m_pBloomRTVA, clear);
    m_pDeviceContext->PSSetShader(m_pBloomBlurPS, nullptr, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &m_pBloomSRVB);
    m_pDeviceContext->Draw(4, 0);
    m_pDeviceContext->PSSetShaderResources(0, 1, &nullSRV);
}

// shadows

void RenderClass::CollectShadowCasters()
{
    m_ShadowCasters.clear();

    for (const SceneModelInstance& inst : m_SceneModelInstances)
    {
        if (!inst.CastShadow)
            continue;

        if (inst.ModelResourceIndex < 0 ||
            inst.ModelResourceIndex >= (int)m_ModelResources.size())
        {
            continue;
        }

        const GltfModelResource& model = m_ModelResources[inst.ModelResourceIndex];

        for (int rootNode : model.Scene.RootNodes)
        {
            std::vector<int> stack;
            stack.push_back(rootNode);

            while (!stack.empty())
            {
                int nodeIndex = stack.back();
                stack.pop_back();

                if (nodeIndex < 0 || nodeIndex >= (int)model.Scene.Nodes.size())
                    continue;

                const GltfNodeData& node = model.Scene.Nodes[nodeIndex];
                XMMATRIX nodeWorld = XMLoadFloat4x4(&node.WorldMatrix);
                XMMATRIX finalWorld = nodeWorld * inst.PrecomputedWorld;

                if (node.MeshIndex >= 0 && node.MeshIndex < (int)model.GpuMeshes.size())
                {
                    const GltfGpuMesh& mesh = model.GpuMeshes[node.MeshIndex];

                    for (const auto& prim : mesh.Primitives)
                    {
                        SceneShadowItem item = {};
                        item.World = finalWorld;
                        item.IndexCount = prim.IndexCount;
                        item.IsGround = false;
                        m_ShadowCasters.push_back(item);
                    }
                }

                for (int child : node.Children)
                    stack.push_back(child);
            }
        }
    }
}

HRESULT RenderClass::CreateShadowResources(UINT shadowMapSize)
{
    ReleaseShadowResources();
    
    m_ShadowMapSize = shadowMapSize;
    
    D3D11_TEXTURE2D_DESC texDesc = {};
    texDesc.Width = shadowMapSize;
    texDesc.Height = shadowMapSize;
    texDesc.MipLevels = 1;
    texDesc.ArraySize = 1;
    texDesc.Format = DXGI_FORMAT_R32_TYPELESS;
    texDesc.SampleDesc.Count = 1;
    texDesc.Usage = D3D11_USAGE_DEFAULT;
    texDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL | D3D11_BIND_SHADER_RESOURCE;
    
    HRESULT hr = m_pDevice->CreateTexture2D(&texDesc, nullptr, &m_pShadowMapTexture);
    if (FAILED(hr))
        return hr;
   
    D3D11_DEPTH_STENCIL_VIEW_DESC dsvDesc = {};
    dsvDesc.Format = DXGI_FORMAT_D32_FLOAT;
    dsvDesc.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
    dsvDesc.Texture2D.MipSlice = 0;
    
    hr = m_pDevice->CreateDepthStencilView(m_pShadowMapTexture, &dsvDesc, &m_pShadowMapDSV);
    if (FAILED(hr))
        return hr;
    D3D11_SHADER_RESOURCE_VIEW_DESC srvDesc = {};
    srvDesc.Format = DXGI_FORMAT_R32_FLOAT;
    srvDesc.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
    srvDesc.Texture2D.MipLevels = 1;
    srvDesc.Texture2D.MostDetailedMip = 0;
    
    hr = m_pDevice->CreateShaderResourceView(m_pShadowMapTexture, &srvDesc, &m_pShadowMapSRV);
    if (FAILED(hr))
        return hr;
    
    D3D11_BUFFER_DESC cbDesc = {};
    cbDesc.Usage = D3D11_USAGE_DYNAMIC;
    cbDesc.ByteWidth = sizeof(ShadowCameraBuffer);
    cbDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    cbDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;
    
    hr = m_pDevice->CreateBuffer(&cbDesc, nullptr, &m_pShadowCameraBuffer);
    if (FAILED(hr))
        return hr;
    
    cbDesc.ByteWidth = sizeof(ShadowParamsCB);
    hr = m_pDevice->CreateBuffer(&cbDesc, nullptr, &m_pShadowParamsBuffer);
    if (FAILED(hr))
        return hr;
    
    cbDesc.ByteWidth = sizeof(ShadowLightBuffer);
    hr = m_pDevice->CreateBuffer(&cbDesc, nullptr, &m_pShadowLightBuffer);
    if (FAILED(hr))
        return hr;
    return S_OK;
}

void RenderClass::ReleaseShadowResources()
{
    if (m_pShadowMapSRV)
    {
        m_pShadowMapSRV->Release();
        m_pShadowMapSRV = nullptr;
    }
    
    if (m_pShadowMapDSV)
    {
        m_pShadowMapDSV->Release();
        m_pShadowMapDSV = nullptr;
    }
    
    if (m_pShadowMapTexture)
    {
        m_pShadowMapTexture->Release();
        m_pShadowMapTexture = nullptr;
    }
    
    if (m_pShadowVertexShader)
    {
        m_pShadowVertexShader->Release();
        m_pShadowVertexShader = nullptr;
    }
    
    if (m_pShadowCameraBuffer)
    {
        m_pShadowCameraBuffer->Release();
        m_pShadowCameraBuffer = nullptr;
    }
    
    if (m_pShadowParamsBuffer)
    {
        m_pShadowParamsBuffer->Release();
        m_pShadowParamsBuffer = nullptr;
    }
    
    if (m_pShadowLightBuffer)
    {
        m_pShadowLightBuffer->Release();
        m_pShadowLightBuffer = nullptr;
    }
    
    if (m_pShadowRasterState)
    {
        m_pShadowRasterState->Release();
        m_pShadowRasterState = nullptr;
    }
    
    if (m_pShadowSampler)
    {
        m_pShadowSampler->Release();
        m_pShadowSampler = nullptr;
    }
}

void RenderClass::UpdateShadowBufferData()
{
    XMVECTOR lightPos = XMLoadFloat3(&m_LightPositions[0]);
    XMVECTOR sceneCenter = XMVectorSet(0.0f, 1.5f, 0.0f, 1.0f);
    XMVECTOR lightDir = XMVector3Normalize(sceneCenter - lightPos);
    XMVECTOR up = XMVectorSet(0, 1, 0, 0);
    if (fabs(XMVectorGetX(XMVector3Dot(lightDir, up))) > 0.98f)
        up = XMVectorSet(0, 0, 1, 0);
    XMMATRIX lightView = XMMatrixLookAtLH(lightPos, sceneCenter, up);
    XMMATRIX lightProj = XMMatrixPerspectiveFovLH(
        XMConvertToRadians(95.0f),
        1.0f,
        0.1f,
        60.0f
    );
    XMMATRIX lightViewProj = lightView * lightProj;
    {
        ShadowCameraBuffer cb = {};
        cb.LightViewProj = XMMatrixTranspose(lightViewProj);
        D3D11_MAPPED_SUBRESOURCE mapped = {};
        if (SUCCEEDED(m_pDeviceContext->Map(m_pShadowCameraBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0,
            &mapped)))
        {
            memcpy(mapped.pData, &cb, sizeof(cb));
            m_pDeviceContext->Unmap(m_pShadowCameraBuffer, 0);
        }
    }
    {
        ShadowParamsCB cb = {};
        cb.ShadowBiasAndTexelSize = XMFLOAT4(
            m_ShadowBias,
            m_ShadowSlopeBias * 0.001f,
            1.0f / (float)m_ShadowMapSize,
            m_ShadowStrength
        );
        D3D11_MAPPED_SUBRESOURCE mapped = {};
        if (SUCCEEDED(m_pDeviceContext->Map(m_pShadowParamsBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0,
            &mapped)))
        {
            memcpy(mapped.pData, &cb, sizeof(cb));
            m_pDeviceContext->Unmap(m_pShadowParamsBuffer, 0);
        }
    }
    {
        ShadowLightBuffer cb = {};
        XMFLOAT3 dir;
        XMStoreFloat3(&dir, lightDir);
        cb.LightViewProj = XMMatrixTranspose(lightViewProj);
        cb.LightDirection = dir;
        cb.ShadowStrength = m_ShadowStrength;
        D3D11_MAPPED_SUBRESOURCE mapped = {};
        if (SUCCEEDED(m_pDeviceContext->Map(m_pShadowLightBuffer, 0, D3D11_MAP_WRITE_DISCARD, 0,
            &mapped)))
        {
            memcpy(mapped.pData, &cb, sizeof(cb));
            m_pDeviceContext->Unmap(m_pShadowLightBuffer, 0);
        }
    }
}


void RenderClass::RenderShadowPass()
{
    if (!m_pShadowMapDSV || !m_pShadowVertexShader)
        return;
    
    ID3D11RenderTargetView* nullRTV = nullptr;
    m_pDeviceContext->OMSetRenderTargets(1, &nullRTV, m_pShadowMapDSV);
    
    m_pDeviceContext->ClearDepthStencilView(
        m_pShadowMapDSV,
        D3D11_CLEAR_DEPTH,
        1.0f,
        0
    );
    
    D3D11_VIEWPORT vp = {};
    vp.Width = (FLOAT)m_ShadowMapSize;
    vp.Height = (FLOAT)m_ShadowMapSize;
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    vp.TopLeftX = 0.0f;
    vp.TopLeftY = 0.0f;
    m_pDeviceContext->RSSetViewports(1, &vp);
    
    m_pDeviceContext->RSSetState(m_pShadowRasterState);
    m_pDeviceContext->VSSetShader(m_pShadowVertexShader, nullptr, 0);
    m_pDeviceContext->PSSetShader(nullptr, nullptr, 0);
    m_pDeviceContext->IASetInputLayout(m_pLayout);
    m_pDeviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    
    m_pDeviceContext->VSSetConstantBuffers(4, 1, &m_pShadowCameraBuffer);
    
    //RenderGroundPlaneShadow();
    RenderAllSceneModelsShadow();
    
    m_pDeviceContext->RSSetState(nullptr);
}

void RenderClass::RenderGroundPlaneShadow()
{
    if (!m_pGroundVB || !m_pGroundIB)
        return;
    
    UINT stride = sizeof(GroundVertex);
    UINT offset = 0;
    
    XMMATRIX world = XMMatrixIdentity();
    XMMATRIX worldT = XMMatrixTranspose(world);
    
    m_pDeviceContext->UpdateSubresource(m_pModelBuffer, 0, nullptr, &worldT, 0, 0);
    m_pDeviceContext->VSSetConstantBuffers(0, 1, &m_pModelBuffer);
    
    m_pDeviceContext->IASetVertexBuffers(0, 1, &m_pGroundVB, &stride, &offset);
    m_pDeviceContext->IASetIndexBuffer(m_pGroundIB, DXGI_FORMAT_R32_UINT, 0);
    m_pDeviceContext->DrawIndexed(m_GroundIndexCount, 0, 0);
}


// utils 

void RenderClass::Resize(HWND hWnd)
{
    if (!m_pSwapChain || !m_pDeviceContext)
        return;

    m_pDeviceContext->OMSetRenderTargets(0, nullptr, nullptr);

    if (m_pRenderTargetView)
    {
        m_pRenderTargetView->Release();
        m_pRenderTargetView = nullptr;
    }

    if (m_pDepthView)
    {
        m_pDepthView->Release();
        m_pDepthView = nullptr;
    }

    if (m_pHDRSceneSRV)
    {
        m_pHDRSceneSRV->Release();
        m_pHDRSceneSRV = nullptr;
    }

    if (m_pHDRSceneRTV)
    {
        m_pHDRSceneRTV->Release();
        m_pHDRSceneRTV = nullptr;
    }

    if (m_pHDRSceneTexture)
    {
        m_pHDRSceneTexture->Release();
        m_pHDRSceneTexture = nullptr;
    }

    ReleaseBloomResources();

    ReleaseShadowResources();
    HRESULT hrShadow = CreateShadowResources(m_ShadowMapSize);
    if (FAILED(hrShadow))
    {
        OutputDebugString(_T("CreateShadowResources failed.\n"));
        return;
    }

    HRESULT hr;

    RECT rc;
    GetClientRect(hWnd, &rc);
    UINT width = rc.right - rc.left;
    UINT height = rc.bottom - rc.top;

    hr = m_pSwapChain->ResizeBuffers(2, width, height, DXGI_FORMAT_R8G8B8A8_UNORM_SRGB, 0);
    if (FAILED(hr))
    {
        MessageBox(nullptr, L"ResizeBuffers failed.", L"Error", MB_OK);
        return;
    }

    HRESULT resultBack = ConfigureBackBuffer(width, height);
    if (FAILED(resultBack))
    {
        MessageBox(nullptr, L"Configure back buffer failed.", L"Error", MB_OK);
        return;
    }

    hr = CreateHDRSceneTexture(width, height);
    if (FAILED(hr))
    {
        OutputDebugString(_T("CreateHDRSceneTexture failed.\n"));
        return;
    }

    hr = CreateBloomResources(width, height);
    if (FAILED(hr))
    {
        OutputDebugString(_T("CreateBloomResources failed.\n"));
        return;
    }

    hr = InitLuminanceResources(width, height);
    if (FAILED(hr))
    {
        OutputDebugString(_T("InitLuminanceResources failed.\n"));
        return;
    }

    m_pDeviceContext->OMSetRenderTargets(1, &m_pRenderTargetView, m_pDepthView);

    D3D11_VIEWPORT vp;
    vp.Width = (FLOAT)width;
    vp.Height = (FLOAT)height;
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    vp.TopLeftX = 0;
    vp.TopLeftY = 0;
    m_pDeviceContext->RSSetViewports(1, &vp);
}

void RenderClass::MoveCamera(float dx, float dy, float dz)
{
    m_CameraPosition.x += dx * m_CameraSpeed;
    m_CameraPosition.y += dy * m_CameraSpeed;
    m_CameraPosition.z += dz * m_CameraSpeed;
}

void RenderClass::RotateCamera(float lrAngle, float udAngle)
{
    m_LRAngle += lrAngle;
    m_UDAngle += udAngle;

    if (m_LRAngle > XM_2PI) m_LRAngle -= XM_2PI;
    if (m_LRAngle < -XM_2PI) m_LRAngle += XM_2PI;

    if (m_UDAngle > XM_PIDIV2) m_UDAngle = XM_PIDIV2;
    if (m_UDAngle < -XM_PIDIV2) m_UDAngle = -XM_PIDIV2;
}

void RenderClass::MouseRBPressed(bool pressed, int x, int y)
{
    m_rbPressed = pressed;
    if (m_rbPressed)
    {
        m_prevMouseX = x;
        m_prevMouseY = y;
    }
}

void RenderClass::MouseMoved(int x, int y, HWND hWnd)
{
    if (m_rbPressed)
    {
        int dx = x - m_prevMouseX;
        int dy = y - m_prevMouseY;

        const float sens = 0.0015f;
        m_LRAngle += dx * sens;
        m_UDAngle -= dy * sens;

        m_UDAngle = std::min(std::max(m_UDAngle, -XM_PIDIV2 + 0.01f), XM_PIDIV2 - 0.01f);

        m_prevMouseX = x;
        m_prevMouseY = y;
    }
}

void RenderClass::MouseWheel(int delta)
{
    float steps = delta * 0.005f;
    XMVECTOR forward = XMVectorSet(
        cosf(m_UDAngle) * sinf(m_LRAngle),
        sinf(m_UDAngle),
        cosf(m_UDAngle) * cosf(m_LRAngle),
        0.0f
    );

    XMVECTOR camPos = XMLoadFloat3(&m_CameraPosition);
    camPos += forward * steps;

    XMStoreFloat3(&m_CameraPosition, camPos);
}

void RenderClass::MoveCube(float dx, float dy, float dz)
{
    m_CubePosition.x += dx * m_CubeMoveSpeed;
    m_CubePosition.y += dy * m_CubeMoveSpeed;
    m_CubePosition.z += dz * m_CubeMoveSpeed;
}

void RenderClass::RenderAllSceneModelsShadow()
{
    for (const SceneModelInstance& instance : m_SceneModelInstances)
        RenderModelInstanceShadow(instance);
}

void RenderClass::RenderModelInstanceShadow(const SceneModelInstance& instance)
{
    if (instance.ModelResourceIndex < 0 ||
        instance.ModelResourceIndex >= (int)m_ModelResources.size())
        return;

    const GltfModelResource& model = m_ModelResources[instance.ModelResourceIndex];
    for (int rootNode : model.Scene.RootNodes)
        RenderGltfNodeShadow(model, rootNode, instance.PrecomputedWorld);
}

void RenderClass::RenderGltfNodeShadow(
    const GltfModelResource& model,
    int nodeIndex,
    const XMMATRIX& instanceWorld)
{
    if (nodeIndex < 0 || nodeIndex >= (int)model.Scene.Nodes.size())
        return;
    
    const GltfNodeData& node = model.Scene.Nodes[nodeIndex];
    XMMATRIX nodeWorld = XMLoadFloat4x4(&node.WorldMatrix);
    XMMATRIX finalWorld = nodeWorld * instanceWorld;
    
    if (node.MeshIndex >= 0 && node.MeshIndex < (int)model.GpuMeshes.size())
    {
        const GltfGpuMesh& mesh = model.GpuMeshes[node.MeshIndex];
        for (const auto& prim : mesh.Primitives)
            DrawGltfPrimitiveShadow(prim, finalWorld);
    }

    for (int child : node.Children)
        RenderGltfNodeShadow(model, child, instanceWorld);
}

void RenderClass::DrawGltfPrimitiveShadow(
    const GltfGpuPrimitive& primitive,
    const XMMATRIX& world)
{
    if (!primitive.VertexBuffer || !primitive.IndexBuffer || primitive.IndexCount == 0)
        return;

    UINT stride = sizeof(GltfVertex);
    UINT offset = 0;

    XMMATRIX worldT = XMMatrixTranspose(world);
    m_pDeviceContext->UpdateSubresource(m_pModelBuffer, 0, nullptr, &worldT, 0, 0);
    m_pDeviceContext->VSSetConstantBuffers(0, 1, &m_pModelBuffer);
    
    m_pDeviceContext->IASetVertexBuffers(0, 1, &primitive.VertexBuffer, &stride, &offset);
    m_pDeviceContext->IASetIndexBuffer(primitive.IndexBuffer, primitive.IndexFormat, 0);
    m_pDeviceContext->DrawIndexed(primitive.IndexCount, 0, 0);
}


// imgui

void RenderClass::InitImGui(HWND hWnd)
{
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    ImGui_ImplWin32_Init(hWnd);
    ImGui_ImplDX11_Init(m_pDevice, m_pDeviceContext);
}

void RenderClass::ShutdownImGui()
{
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
}

void RenderClass::RenderImGui()
{
    m_pDeviceContext->OMSetRenderTargets(1, &m_pRenderTargetView, nullptr);

    RECT rc;
    GetClientRect(FindWindow(m_szWindowClass, m_szTitle), &rc);

    D3D11_VIEWPORT vp = {};
    vp.Width = float(rc.right - rc.left);
    vp.Height = float(rc.bottom - rc.top);
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    vp.TopLeftX = 0.0f;
    vp.TopLeftY = 0.0f;
    m_pDeviceContext->RSSetViewports(1, &vp);

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();

    ImGui::Begin("Lights");
    for (int i = 0; i < 3; i++)
    {
        char colorLabel[32];
        char brightLabel[32];
        sprintf_s(colorLabel, "Light %d color", i);
        sprintf_s(brightLabel, "Light %d brightness", i);
        ImGui::ColorEdit3(colorLabel, &m_LightColors[i].x);
        ImGui::SliderFloat(brightLabel, &m_LightBrightness[i], 0.0f, 3.0f);
        ImGui::Separator();
    }
    ImGui::End();

    ImGui::Begin("Material");
    //ImGui::Checkbox("Enable textures", &m_EnableTextures);
    //ImGui::SliderFloat("Metalness", &m_MaterialMetalness, 0.0f, 1.0f);
    //ImGui::SliderFloat("Roughness", &m_MaterialRoughness, 0.02f, 1.0f);
    //ImGui::SliderFloat("AO", &m_MaterialAO, 0.0f, 1.0f);
    //ImGui::SliderFloat("Normal strength", &m_NormalStrength, 0.0f, 2.0f);
    //ImGui::ColorEdit3("Color", &m_MaterialColor.x);

    //ImGui::Separator();
    ImGui::Checkbox("Enable specular IBL", &m_EnableSpecularIBL);
    ImGui::SliderFloat("Diffuse IBL intensity", &m_DiffuseIBLIntensity, 0.0f, 3.0f);
    ImGui::SliderFloat("Specular IBL intensity", &m_SpecularIBLIntensity, 0.0f, 3.0f);

    static const char* debugModes[] =
    {
        "Final",
        "Normal Distribution Function",
        "Geometry Function",
        "Fresnel Function",
        "Diffuse IBL",
        "Specular IBL",
        "Ambient IBL",
        "Reflection only"
    };

    ImGui::Combo("View mode", &m_DebugViewMode, debugModes, IM_ARRAYSIZE(debugModes));
    ImGui::End();

    ImGui::Begin("Environment");
    if (!m_environmentFileNames.empty())
    {
        std::vector<const char*> items;
        for (const auto& name : m_environmentFileNames)
            items.push_back(name.c_str());

        if (ImGui::Combo("HDRI map", &m_currentEnvIndex, items.data(), static_cast<int>(items.size())))
        {
            if (m_currentEnvIndex >= 0 &&
                m_currentEnvIndex < static_cast<int>(m_environmentFiles.size()) &&
                m_currentEnvIndex != m_prevEnvIndex)
            {
                LoadEnvironmentMap(m_environmentFiles[m_currentEnvIndex].c_str());
                m_prevEnvIndex = m_currentEnvIndex;
            }
        }
    }
    ImGui::End();

    ImGui::Begin("Bloom");
    ImGui::Checkbox("Enable bloom", &m_EnableBloom);
    ImGui::SliderFloat("Threshold", &m_BloomThreshold, 0.1f, 10.0f);
    ImGui::SliderFloat("Intensity", &m_BloomIntensity, 0.0f, 3.0f);
    ImGui::SliderFloat("Blur scale", &m_BloomBlurScale, 0.5f, 3.0f);
    ImGui::End();


    ImGui::Render();
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}